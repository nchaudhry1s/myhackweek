require 'resque-retry'
require 'resque/failure/redis'

## Setup multiple failure backend
## This will ensure that failures will NOT be logged in Resque::Failure until the final retry attempt fails
## Should help to keep our failure queue (Resque::Failure) from becoming overpopulated with attempts that were retried and completed successfully
Resque::Failure::MultipleWithRetrySuppression.classes = [Resque::Failure::Redis]
Resque::Failure.backend = Resque::Failure::MultipleWithRetrySuppression
Resque.schedule = YAML.load_file(File.join(Rails.root, 'config', 'resque_schedule.yml'))
