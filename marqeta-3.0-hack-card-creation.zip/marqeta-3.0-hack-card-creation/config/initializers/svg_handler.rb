ActionView::Template.register_template_handler :svg, ActionView::Template.registered_template_handler(:erb)
