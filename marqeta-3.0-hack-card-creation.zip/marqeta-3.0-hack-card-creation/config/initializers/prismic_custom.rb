module Prismic

  class Document
  # Simply to avoid typing .html_safe at the end of each as_html call.
    def as_html_safe(link_resolver = nil)
      as_html(link_resolver).html_safe
    end
  end

  module Fragments
    class Fragment
      # Simply to avoid typing .html_safe at the end of each as_html call.
      def as_html_safe(link_resolver = nil)
        as_html(link_resolver).html_safe
      end
    end
  end
end

