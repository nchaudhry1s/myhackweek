require 'rubygems'
require 'sitemap_generator'
require 'prismic'

sitemap = SitemapGenerator::LinkSet.new({
  default_host:  "https://www.marqeta.com",
  compress:      false,
  create_index:  :auto,
  filename:      :sitemap,
  include_index: false,
  include_root:  false
})

config       = YAML.load_file(Rails.root.join("config", "settings.yml"))
url          = config.fetch('url')
access_token = config.fetch('token')
api          = Prismic.api(url, access_token: access_token)
types        = api.types.keys
ref          = api.master_ref.ref

types.each do |type|

  query = "[[:d = at(my.#{type}.include_in_index, \"yes\")]]"

  begin
    documents = api.form("everything").page_size(100).query(query).submit(ref)
  rescue Prismic::SearchForm::FormSearchException => e
    puts "Rescued error while generating sitemap for type \"#{type}\": #{e}"
    next
  end

  documents.each do |document|
    index_order_fragment = document.get_number("#{type}.index_order")
    index_order = index_order_fragment.value unless index_order_fragment.nil?
    priority = (index_order.nil? || index_order < 1 || index_order > 10) ? 0.5 : (index_order / 10)

    sitemap.add(PrismicLinkResolver.build_link(document), {
      priority:   priority,
      changefreq: nil,
      lastmod:    nil
    })
  end

end

sitemap.finalize!
