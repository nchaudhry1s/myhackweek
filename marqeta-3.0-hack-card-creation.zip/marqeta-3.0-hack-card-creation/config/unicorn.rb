# Application path
APP_PATH = '/srv/www/marqeta-3.0'

# Process configuration
worker_processes 4
user 'mqdeploy', 'mqdeploy'

# Connection configuration
listen 4001, tcp_nopush: true
timeout 30

# Paths
working_directory APP_PATH + '/current'
pid APP_PATH + '/shared/pids/unicorn.pid'
stderr_path APP_PATH + '/shared/log/unicorn.stderr.log'
stdout_path APP_PATH + '/shared/log/unicorn.stdout.log'

preload_app false # Don't preload for the moment but would be nice to figure this out
