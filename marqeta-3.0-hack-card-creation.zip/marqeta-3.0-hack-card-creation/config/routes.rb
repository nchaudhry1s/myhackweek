Rails.application.routes.draw do

    devise_for :users, controllers: {
      sessions:  "sessions",
      registrations: "registrations",
      confirmations: "confirmations",
      passwords: "passwords"
    }

    devise_scope :user do
      # Do we need this?
    end

    resources :users, only: [:update]
    post '/users/delete', to: 'users#delete'

    get 'api-explorer', to: 'api_explorer#index'
    get '/tools/card-creation', to: 'tools#card_creation'
    root 'pages#home'

    post '/cache-warming' , to: 'cache#warm_site_cache'
    get '/ping'        , to: 'health#check_health'

    get :search                , to: 'application#search'      , as: :search
    get :previews              , to: 'application#preview'     , as: :preview
    get :downlad               , to: 'application#download'    , as: :download
    get 'releases/:release_id' , to: 'application#set_release' , as: :releases
    get :api                   , to: 'pages#api'
    get :features              , to: 'pages#features'
    get :careers               , to: 'pages#careers'
    get :culture               , to: 'pages#culture'
    get :help                  , to: 'pages#help'
    get :partners              , to: 'pages#partners'
    get 'payments-basics'      , to: 'pages#payments_basics'
    get :press                 , to: 'pages#press'
    get :sdk                   , to: 'pages#sdk'
    get :about                 , to: 'pages#about'
    get :contact               , to: 'pages#contact'

    # # Fixed page
    get :terms               , to: 'pages#show'
    get 'api-terms'          , to: 'pages#show'
    get 'privacy'            , to: 'pages#show'
    get 'managed-services'   , to: redirect('/features#managed-services')
    get 'terms-of-service'   , to: redirect('/terms')

    get '/managed-services/program-admin'  , to: redirect('/managed-services/program-dashboard')
    get '/managed-services/other-services' , to: redirect('/managed-services/pci-widgets')
    get '/managed-services/program-dashboard', to: 'managed_services#program_dashboard'

    get '/managed-services/:id', to: 'managed_services#show', as: 'managed_services_page'

    # # Solutions pages
    # # Set the redirect first or it will get overwritten
    match '*path', to: redirect('solutions/disburse'), via: :all, constraints: {
        path: 'solutions/VhyfmRwAAB8A_RtO/perk-building-a-rewards-platform-for-consumers'
    }
    match '*path', to: redirect('solutions/expense'), via: :all, constraints: {
        path: 'solutions/ViaAExwAAN8AtZai/classwallet-payment-solution-for-teachers'
    }
    get '/solutions/:id'       , to: 'solutions#show' , as: 'solutions_page'
    get '/solutions/:id/:slug' , to: 'pages#show'

    # # Document detail
    get 'api/guides/VhytWxwAANkA_W3-/real-time-funding', to: redirect('api/guides/Vhyr5RwAANwA_WTt/delivery#funding')
    get 'api/guides/VhysGRwAAB8A_WYu/secure-virtual-card', to: redirect('api/guides/WAkMaiYAAFIGPPrH/virtual')
    get 'api/docs/Vh2fDRwAAB8AF4dN/customer-configurations', to: redirect('api/docs/VtYzOykAAIApkN7P/configure-card-product')
    get 'api/docs/Vh2e9BwAABwAF4aw/response-codes', to: redirect('/api/docs/Vh2cTBwAAB8AF3aI/errors#response_codes')

    get 'api/guides/VhysGRwAAB8A_WYu/virtual', to: redirect('api/guides/WAkMaiYAAFIGPPrH/virtual')
    get 'api/docs/Vh2e1BwAAMAAF4Xp/transaction-events' , to: redirect('api/docs/VjFJjCYAAM4A3YfI/event-types')
    get 'api/docs/VtZAcSkAAIApkSo2/requestresponse-models', to: redirect('api/docs/VtZAcSkAAIApkSo2/jit-funding-message-models')
    get 'api/docs/:id/:slug'      , to: 'references#show', as: :references_doc
    match '*path', to: redirect('/api/docs/VtTqsikAAHoQiUV_/jit-funding-overview'), via: :all, constraints: {
            path: 'api/guides/VhytWxwAANkA_W3-/just-in-time-jit-funding'
    }
    match '*path', to: redirect('/api/guides/Vhyr5RwAANwA_WTt/delivery'), via: :all, constraints: {
            path: 'api/guides/(VhysABwAANkA_WWR|VhysMhwAAB0A_WbL|VhysTBwAAB0A_Wdu|VhysdxwAANwA_Wh6|VhgMLB4AABwAZWjx|VhytLRwAANkA_Wzg|VhytgBwAANwA_W7p|Vhyr5RwAANwA_WTt)/(parent-child-spending|e-wallet-integration|pay-with-points|peer-to-peer-transfer|all-purpose-prepaid|card-aggregator|closed-loop-prepaid|on-demand-delivery)'
    }
    get 'api/guides/:id/:slug'    , to: 'guides#show',     as: :api_guide

    #Errors Pages
    get "/404", :to => "errors#not_found"
    get "/500", :to => "errors#internal_error"

    # Redirect section BEGIN
    get 'docs/:id/:slug', to: redirect('/api/docs/%{id}/%{slug}')

    get 'guides/:id/:slug', to: redirect('/api/guides/%{id}/%{slug}')

    get '/platform' , to: redirect('/features')
    get '/capabilities' , to: redirect('/features')
    get '/contact'  , to: redirect('/about')
    get '/powered'  , to: redirect('/solutions/delivery')
    get '/inside'   , to: redirect('/features')
    get '/dmcterms' , to: redirect('/api-terms')
    get '/solutions' , to: redirect('/solutions/delivery')
    get '/managed-services/email-services' , to: redirect('/features')

    # wildcards
    match '*path', to: redirect('/'), via: :all, constraints: {
            path: '(blog|ship|faqs|programs|offers|dashboard|tag|shopandgive).*'
    }
    match '*path', to: redirect('api/docs/ViBKPB0AAMIA4Axf/authentication'), via: :all, constraints: {
            path: 'endpoints.*|api/docs.*|docs.*',
    }
    match '*path', to: redirect('/api'), via: :all, constraints: {
            path: 'getting-started.*'
    }
    match '*path', to: redirect('api/guides/Vhyr5RwAANwA_WTt/delivery'), via: :all, constraints: {
            path: 'use-cases.*|api/guides.*|guides.*'
    }
    match '*path', to: redirect('privacy'), via: :all, constraints: {
        path: 'privacy.*'
    }

    # Redirect section END

end
