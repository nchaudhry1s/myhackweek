# TODO deprecate after soft launch
module SoftLaunch
  SECRET_PASSWORD = "open_sesame"

  def self.included(base)
    base.before_filter :activate_soft_launch
    base.before_filter :check_if_soft_launch_activated
    base.helper_method :soft_launch_active?
  end

  def activate_soft_launch
    if current_user || (SoftLaunch.passwords_match?(params[:soft_launch]) && !soft_launch_active?)
      session[:soft_launch] = true
    end
  end

  def check_if_soft_launch_activated
    return unless ["sessions", "registrations"].include?(controller_name)
    unless soft_launch_active?
      redirect_to root_path
    end
  end

  def soft_launch_active?
    session[:soft_launch] || false
  end

  def self.passwords_match?(password)
    SECRET_PASSWORD == password
  end
end
