class SimpleCollection

  attr_reader :count, :all, :start_index, :end_index, :is_more

  def initialize(collection = [], start_index = nil, end_index = nil, is_more = nil, count = nil)
    @count       = count || collection.size
    @start_index = start_index
    @end_index   = end_index
    @is_more     = is_more
    @all         = collection
  end

  alias :size :count

  def first
    @all.first
  end

  def last
    @all.last
  end

  def errors
    {}
  end

end
