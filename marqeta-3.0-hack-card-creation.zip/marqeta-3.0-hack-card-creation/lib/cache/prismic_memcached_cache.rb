# encoding: utf-8
class PrismicMemcachedCache

  def initialize(max_size=100)
  end

  def set(key, value, expires_in = nil)
    Rails.cache.write(key, value, expires_in: expires_in)
    value
  end

  def []=(key, value)
    set(key, value, nil)
  end

  def get(key)
    Rails.cache.fetch(key)
  end
  alias :[] :get

  def get_or_set(key, value = nil, expired_in = nil)
    if include?(key) && !expired?(key)
      return get(key)
    else
      set(key, block_given? ? yield : value, expired_in)
    end
  end

  def delete(key)
    Rails.cache.delete(key)
    nil
  end

  def has_key?(key)
    Rails.cache.exist?(key)
  end
  alias :include? :has_key?

  def expired?(key)
    if include?(key) && get[key][:expired_in] != nil
      expired_in = get[key][:expired_in]
      expired_in && expired_in < Time.now.getutc.to_i
    else
      false
    end
  end


  def invalidate_all!
    Rails.cache.clear
  end
  alias :clear! :invalidate_all!

  # Expose the Hash keys
  #
  # This is only for debugging purposes.
  #
  # @return [Array<String>]
  def keys
    nil
  end

  # Return the number of stored keys
  #
  # @return [Fixum]
  def size
    nil
  end
  alias :length :size

  # This default instance is used by the API to avoid creating a new instance
  # per request (which would make the cache useless).
  DefaultCache = ::PrismicMemcachedCache.new
end
