module PrismicApi
  def prismic_api
    return false if PrismicStatus.api_down?
    begin
      Prismic.api(config('url'), {
        access_token: config('token'),
        cache: Prismic::BasicNullCache.new
      })
    rescue Exception => e
      Rails.logger.error "+++ There was an error initializing the prismic api at #{Time.now} and the error was #{e} +++"
      return false
    end
  end

  def config(key=nil)
    @@config ||= YAML.load(ERB.new(File.read(Rails.root + "config/prismic.yml")).result)
    key ? @@config.fetch(key) : @@config
  end
end
