class CreateCredentialsModel < ActiveRecord::Migration
  def change
    create_table :credentials do |t|
      t.string :auth_token,
               :credential_type,
               :environment,
               :app_token

      t.integer :program_id
      t.integer :user_id

      t.timestamps null: false
    end
  end
end
