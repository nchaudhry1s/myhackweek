class AddDateToPrismicStatus < ActiveRecord::Migration
  def change
    add_column :prismic_statuses, :date, :string
  end
end
