class PrismicBackups < ActiveRecord::Migration
  def change
    create_table :prismic_backups do |t|
      t.string :prismic_id
      t.string :prismic_type
      t.binary :prismic_object, :limit => 10.megabyte
      t.binary :json, :limit => 10.megabyte
      t.string :ref

      t.timestamps
    end

  end
end
