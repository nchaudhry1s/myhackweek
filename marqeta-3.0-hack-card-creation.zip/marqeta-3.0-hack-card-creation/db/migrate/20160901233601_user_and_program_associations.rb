class UserAndProgramAssociations < ActiveRecord::Migration
  def change
    create_table :programs do |t|
      t.string :name
      t.string :account_id

      t.timestamps null: false
    end

    create_table :user_program_records do |t|
      t.belongs_to :program, index: true
      t.belongs_to :user, index: true
      t.string     :salesforce_contact_id

      t.timestamps null: false
    end
  end
end
