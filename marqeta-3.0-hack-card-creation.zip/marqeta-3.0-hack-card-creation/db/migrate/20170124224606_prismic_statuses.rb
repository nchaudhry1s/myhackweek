class PrismicStatuses < ActiveRecord::Migration
  def change
    create_table :prismic_statuses do |t|
      t.boolean :api_down, default: false

      t.timestamps
    end
  end
end
