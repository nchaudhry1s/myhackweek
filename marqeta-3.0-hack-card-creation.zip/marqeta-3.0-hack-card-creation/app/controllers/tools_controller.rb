class ToolsController < ApplicationController

  def card_creation
    data = BasicPageDataService.new(ref).data_for(:card_creation)
    @facade = BaseFacade.new().use_data(data || {})
  end

end
