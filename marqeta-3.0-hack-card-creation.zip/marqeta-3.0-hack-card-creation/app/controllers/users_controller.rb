class UsersController < ApplicationController
  include UserManipulation
  authorize_resource

  skip_authorize_resource :only => :delete
  skip_before_action :verify_authenticity_token, only: [:delete]
  before_action :allow_salesforce, only: [:delete]

  before_action :authenticate_user!, only: [:update]
  before_action :confirmed_user?, only: [:update]
  before_action :set_user, only: [:update]
  before_action :restrict_profile_access, only: [:update]


  def delete
    hashed_xml = Hash.from_xml(request.body.read)
    user_id = fetch_id(hashed_xml)
    user_state = fetch_state(hashed_xml)
    user = User.find(user_id)
    if user && terminated_via_salesforce?(user_state) && user.active?
      Resque.enqueue(ZionDeleteJob, user.id)
      user.terminate!
    end
    render :nothing => true
  end

  def update
    set_user_vars(@user)
    delete_roles(@user)
    add_roles(@user)
    if @user.save
      Resque.enqueue(SalesforceContactUpdateJob, @user.id, current_program.name)
      return redirect_to :back, flash: { notice: "Your profile has been successfully updated." }
    else
      return redirect_to :back, flash: { notice: "We're sorry. Something went wrong while trying to update your account." }
    end
  end

  private

  def allow_salesforce
    unless has_callback_id?
      render :nothing => true, :status => 401
    end
  end

  def confirmed_user?
    # Don't allow user to view/edit their own profile until they confirm their email
    unless current_user.confirmed?
      flash[:error] = "Please confirm your email address before continuing."
      redirect_to root_path
    end
  end

  def fetch_id(xml_hash)
    xml_hash["Envelope"]["Body"]["notifications"]["Notification"]["sObject"]["c_ID__c"]
  end

  def fetch_state(xml_hash)
    xml_hash["Envelope"]["Body"]["notifications"]["Notification"]["sObject"]["status__c"]
  end

  def has_callback_id?
    params[:callback_id] == Marqeta30.config[:salesforce][:secret_uuid]
  end

  def restrict_profile_access
    # Don't allow user to view/edit any other user's profile
    unless current_user.id == params[:id].to_i
      flash[:error] = "You cannot access that page."
      redirect_to root_path
    end
  end

  def set_user
    @user ||= current_user
  end

  def terminated_via_salesforce?(state)
    state.downcase == "terminated"
  end

end
