class RegistrationsController < Devise::RegistrationsController
  include UserManipulation
  layout "session_layout"

  def create
    super do
      resend_email_and_redirect(resource) and return if duplicate_user?(resource)
      if resource.valid?
        set_user_vars(resource)
        set_program(resource)
        add_roles(resource)
        resource.save
      else
        flash[:error] = resource.errors.full_messages.first
      end
    end
  end

  # This method is used solely for updating password currently (& potentially updating email in the future)
  # Please refer to Users#Update if you are looking for the action in which a user's profile info is updated
  def update
    # From Devise, copied here because resource does not come up as 'invalid' if the new password doesn't get set properly
    self.resource = resource_class.to_adapter.get!(send(:"current_#{resource_name}").to_key)
    prev_unconfirmed_email = resource.unconfirmed_email if resource.respond_to?(:unconfirmed_email)

    resource_updated = update_resource(resource, account_update_params)
    yield resource if block_given?
    if resource_updated
      if is_flashing_format?
        flash_key = update_needs_confirmation?(resource, prev_unconfirmed_email) ?
          :update_needs_confirmation : :updated
        set_flash_message :notice, flash_key
      end
      # Our code added here to return user back to where they came from
      sign_in resource, bypass: true
      return redirect_to :back
    else
      clean_up_passwords resource
      # Our code added here to tell the modal to re-render and flash the relevant errors
      flash[:password_update_error] = true
      flash[:error] = resource.errors.full_messages.first
      return redirect_to :back
    end
  end

  def after_inactive_sign_up_path_for(resource)
    resource.active? ? new_user_confirmation_path : super
  end

  private

  def duplicate_user?(resource)
    # If the user is in the database, not confirmed & the resource is invalid, that means that User has already registered
    !!original_user(resource) && !original_user_confirmed?(resource) && !resource.valid?
  end

  def original_user(resource)
    User.find_by_email(resource.email)
  end

  def original_user_confirmed?(resource)
    original_user(resource).confirmed?
  end

  def resend_email_and_redirect(resource)
    original_user(resource).send_confirmation_instructions
    flash[:notice] = "A new confirmation email has been sent. Please check your email inbox."
    redirect_to new_user_confirmation_path
  end

  def sign_up_params
    params.require(:user).permit(:first_name, :last_name, :email, :password, :password_confirmation, :email_opt_in)
  end

  def set_program(resource)
    # Hardcoded as there is only one program on launch - Shared Sandbox
    resource.programs << Program.shared_sandbox
  end
end
