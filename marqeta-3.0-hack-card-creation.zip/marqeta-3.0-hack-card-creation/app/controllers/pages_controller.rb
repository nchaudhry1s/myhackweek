class PagesController < ApplicationController

  before_action :prismic, except: [:home]
  before_action :create_basic_page_facade, only: [:api, :payments_basics]
  before_action :create_static_page_facade, only: [:about, :careers]

  def show
    if unique_page
      @document = unique_page
    else
      document_id = params[:id]
      @document = CmsService.new(id: document_id, ref: ref).retrieve
    end
    @content_cache_key = @document.id.to_s + ref.to_s + 'pagecontent'

    @facade = BaseFacade.new().use_data({
      title_tag: PrismicData.get_value(@document, 'title_tag', ref),
      meta_description: PrismicData.get_value(@document, 'meta_description', ref)
    })
  end

  def features
    data = FeatureDataService.new(ref).data
    raise Error500 if data.blank?
    @facade = FeaturesFacade.new().use_data(data)
  end

  def unique_page
    uri = URI(request.original_url)
    path = uri.path.split('/').last
    return CmsService.init_by_title(title: path, ref: ref).retrieve
  end

  def home
    data = HomeDataService.new(ref).data
    @facade = HomeFacade.new().use_data(data)
  end

  def press
    data = PressDataService.new(ref).data
    @facade = BaseFacade.new().use_data(data)
  end

  def contact
    data = ContactDataService.new(ref).data
    @facade = BaseFacade.new().use_data(data)
  end

  def culture
    data = CultureDataService.new(ref).data
    @facade = BaseFacade.new().use_data(data)
  end

  private

  def create_static_page_facade
    data = StaticDataService.new(ref).data_for(action_name)
    @facade = BaseFacade.new().use_data(data || {})
  end

  def create_basic_page_facade
    data = BasicPageDataService.new(ref).data_for(action_name)
    @facade = BaseFacade.new().use_data(data || {})
  end

end
