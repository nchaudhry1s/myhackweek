class ErrorsController < ApplicationController
  before_action :prismic

  def not_found
    @facade = BaseFacade.new().use_data({ title_tag: '404', meta_description: 'Not Found' })
    render :status => 404
  end

  def internal_error
    @facade = BaseFacade.new().use_data({ title_tag: '500', meta_description: 'Error' })
    render :status => 500
  end

end
