class PasswordsController < Devise::PasswordsController
  layout "session_layout"
end
