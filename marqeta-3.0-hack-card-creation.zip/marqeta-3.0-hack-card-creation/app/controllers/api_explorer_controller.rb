class ApiExplorerController < ApplicationController

  def index
    data = BasicPageDataService.new(ref).data_for(:api_explorer)
    @facade = BaseFacade.new().use_data(data || {})
  end

end
