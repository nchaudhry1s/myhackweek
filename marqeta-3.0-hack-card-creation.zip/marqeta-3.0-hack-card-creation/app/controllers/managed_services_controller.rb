class ManagedServicesController < ApplicationController

  def show
    id = params[:id]
    data = data_service.data_for(id)
    raise Error404 if data.blank?
    @facade = ManagedServicesFacade.new()
      .use_data(data, { wrapper_id: id })
  end

  def program_dashboard
    data = ManagedServicesSubpageDataService.new(ref).data
    @facade = BaseFacade.new().use_data(data)
  end

  private
  def data_service
    ManagedServicesDataService.new(ref)
  end

end
