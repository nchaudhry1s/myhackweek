class GuidesController < ApplicationController
  def show
    document_id = params[:id]
    cache_hash = document_id + params[:slug] + ref.to_s

    @document  = CmsService.new(id: document_id, ref: ref).retrieve
    @documents = CmsService.new(type: @document.type, ref: ref).retrieve

    @api_content_cache_key = "#{cache_hash}apicontent"

    @facade = BaseFacade.new().use_data({
      title_tag: PrismicData.get_value(@document, 'title_tag', ref),
      meta_description: PrismicData.get_value(@document, 'meta_description', ref)
    })
  end
end
