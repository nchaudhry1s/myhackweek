class SessionsController < Devise::SessionsController
  layout "session_layout"

  before_filter :check_user_confirmation, only: :create

  private

  def after_sign_in_path_for(resource)
    redirect_location = stored_location_for(:user)
    if resource.first_login?
      redirect_location ? non_root_intro_flow(redirect_location) : root_path(intro_flow: true)
    else
      redirect_location || root_path
    end
  end

  def after_sign_out_path_for(resource)
    back_to_previous_page || root_path
  end

  def back_to_previous_page
    referrer = URI(request.referrer)
    referrer.query = nil
    referrer.to_s
  end

  def check_user_confirmation
    user = User.find_by_email(params[:user][:email])
    # If User has not been confirmed, re-send email & redirect to confirmations#new
    if user && !user.confirmed?
      user.send_confirmation_instructions
      redirect_to new_user_confirmation_path
    end
  end

  def non_root_intro_flow(redirect_location)
    redirect_uri = URI(redirect_location)
    hashed_query = Rack::Utils.parse_nested_query(redirect_uri.query)
    redirect_uri.query = (hashed_query.merge({ "intro_flow" => "true" })).to_query
    redirect_uri.to_s
  end

end
