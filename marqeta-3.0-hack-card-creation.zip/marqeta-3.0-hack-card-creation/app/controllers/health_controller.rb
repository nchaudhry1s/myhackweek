class HealthController < ApplicationController

  skip_before_action :verify_authenticity_token
  skip_before_action :prismic
  skip_before_action :authenticate

  def check_health
    result = test_resources
    if result[:success]
      render json: result, status: 200, content_type: 'application/json'
    else
      render json: result, status: 503, content_type: 'application/json'
    end
  end

  private
  def test_resources
    prismic_check = component_healthy?("Prismic") do
      CmsService.prismic_api
    end
    twitter_check = component_healthy?("Twitter") do
      begin
        @telnet = Net::Telnet.new("Host" => "api.twitter.com", "Port" => 443)
      ensure
        @telnet.close # prevent connection leak
      end
    end
    {
      success: prismic_check[:healthy] && twitter_check[:healthy],
      version: version,
      revision: revision,
      timestamp: Time.now.utc,
      env: environment,
      system_components: [
        prismic_check,
        twitter_check
      ]
    }
  end

  def component_healthy?(name)
    health = {
      component: name,
      healthy: nil,
      fatal: nil,
      status: nil
    }
    begin
      yield
      health[:healthy] = true
      health[:status]  = "OK"
      health[:fatal]   = false
    rescue Exception => e
      health[:healthy] = false
      health[:status]  = "DOWN"
      health[:fatal]   = true
    end
    health
  end

  def environment
    Rails.env
  end

  def revision
    Marqeta30.config[:build][:revision]
  end

  def version
    Marqeta30.config[:build][:version]
  end

end
