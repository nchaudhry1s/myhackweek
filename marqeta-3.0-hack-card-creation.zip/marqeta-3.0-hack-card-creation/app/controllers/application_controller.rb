class ApplicationController < ActionController::Base
  include Releases
  include PrismicHelper
  include CmsConvenienceMethods
  include Wamtrak::ControllerHelper

  helper_method :get_order, :get_title
  rescue_from Error404, :with => :render_404
  rescue_from Error500, :with => :render_500

  protect_from_forgery with: :exception
  before_action :init_prismic_api,
                :authenticate,
                :set_current_program,
                :pass_gon_information,
                :store_current_location, :unless => :devise_controller?

  # Rescue OAuth errors for some actions
  rescue_from Prismic::Error, with: :render_500

  def init_prismic_api
    @prismic ||= CmsService.prismic_api
  end

  # For writers to preview a draft with the real layout
  def preview
    preview_token = params[:token]
    redirect_url = prismic.preview_session(preview_token, preview_link(), '/')
    cookies[Prismic::PREVIEW_COOKIE] = { value: preview_token, expires: 30.minutes.from_now }
    redirect_to redirect_url
  end

  def download
    send_file "#{Rails.root}/app/assets/images/#{params[:file]}", :type=> ("image/" + params[:type]) , :x_sendfile=>true
  end

  def get_order(documents)
    @parts = documents.partition { |doc| doc[doc.type+'.order'].nil? || get_title(doc).nil? }
    @parts.last.sort_by {|doc| doc[doc.type+'.order'].value}
  end

  def get_title(document)
    document[document.type+'.title'].nil? ? nil
    : document[document.type+'.title'].as_html_safe(link_resolver())
  end

  def render_404
    @facade = BaseFacade.new().use_data({ title_tag: 'Page Not Found' })
    render :not_found, :status => 404
  end

  def render_500
    @facade = BaseFacade.new().use_data({ title_tag: 'Unexpected Error' })
    render :internal_server_error, :status => 500
  end

  private
  def cache_warming_request?
    request.parameters["controller"] == "cache"
  end

  def authenticate
    return true unless Rails.env.qa?
    return true if cache_warming_request?

    authenticate_or_request_with_http_basic do |username, password|
      check_user_pass_combo(username, password)
    end
  end

  def check_user_pass_combo(username, password)
    (username == "mq" && password == "SunsetCrater6201") ||
    (username == "marqetafriend" && password == "friend2016")
  end

  # Set the program - At launch it will default to "Shared Sandbox", as we will not have other programs built in
  # In the future, we will need to pass the current program in the parameters so it gets set
  def set_current_program
    RequestStore.store[:current_program] = params[:program_id] || Program.shared_sandbox
  end

  def current_program
    RequestStore.store[:current_program] || set_current_program
  end

  def pass_gon_information
    swagger_url
    if user_signed_in?
      swagger_authorization
      hello_world_data
    else
      cta_options
    end
  end

  def api_terms?
    uri = URI(request.original_fullpath)
    path = uri.path
    path == "/api-terms"
  end

  def cta_options
    gon.cta_copy = GlobalConstants::CTA_COPY
    gon.button_copy = GlobalConstants::BUTTON_COPY
  end

  # Override devise helper to store the location that the user is coming from before clicking sign-in
  def store_current_location
    unless api_terms?
      store_location_for(:user, request.url)
    end
  end

  def swagger_url
    gon.swagger_domain = Marqeta30.config[:swagger][:payments_host]
  end

  ## If not production, set flag to indicate that user credentials should be sent when retrieving swagger spec
  def swagger_authorization
    gon.swagger_auth = Base64.strict_encode64([current_user.safe_app_token, current_user.safe_auth_token].join(":"))
    gon.auth_swagger = !Rails.env.production?
  end

  def hello_world_data
    gon.hello_world_first_name = Faker::Name.first_name;
    gon.hello_world_last_name = Faker::Name.last_name;
  end
end
