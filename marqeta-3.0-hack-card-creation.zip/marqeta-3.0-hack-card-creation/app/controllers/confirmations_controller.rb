class ConfirmationsController < Devise::ConfirmationsController
  layout "session_layout"

  private

  def after_confirmation_path_for(resource_name, resource)
    begin
      ZionService.provision_zion_credentials(resource.id)
    rescue => error
      flash[:error] = "We are sorry, something went wrong while provisioning credentials. Please contact apiaccess@marqeta.com for more details."
    end
    Resque.enqueue(SalesforceContactCreateJob, resource.id, current_program.name)
    Mailer.post_confirmation(resource).deliver
    super
  end

end
