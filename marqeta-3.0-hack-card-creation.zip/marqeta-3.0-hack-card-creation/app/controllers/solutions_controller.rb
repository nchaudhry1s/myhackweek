class SolutionsController < ApplicationController

  def show
    data = SolutionsDataService.new(ref).data_for(params[:id])
    raise Error404 if data.blank?
    @facade = SolutionsFacade.new()
      .use_data(data, { wrapper_class: params[:id] })
  end

end
