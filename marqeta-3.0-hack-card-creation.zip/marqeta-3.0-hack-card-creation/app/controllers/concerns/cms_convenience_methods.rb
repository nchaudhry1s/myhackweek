require 'active_support/concern'

# The necessary methods your controller needs to use prismic.io transparently
module CmsConvenienceMethods
  extend ActiveSupport::Concern

  private

  # Setting @ref as the actual ref id being queried, even if it's the master ref.
  # To be used to call the API, for instance: prismic.form('everything').submit(ref)
  def ref
    return if PrismicStatus.api_down?
    @ref ||= preview_ref || release_ref || experiment_ref || prismic.master_ref
  end

  def release_ref
    return if PrismicStatus.api_down?
    prismic.refs.select { |key, ref| ref.id == session[:release_id] }.values.first
  end

  def preview_ref
    if request.cookies.has_key?(Prismic::PREVIEW_COOKIE)
      request.cookies[Prismic::PREVIEW_COOKIE]
    else
      nil
    end
  end

  def experiment_ref
    if request.cookies.has_key?(Prismic::EXPERIMENTS_COOKIE)
      prismic.experiments.ref_from_cookie(request.cookies[Prismic::EXPERIMENTS_COOKIE])
    else
      nil
    end
  end

  ##

  # Easier access and initialization of the Prismic::API object.
  def prismic
    CmsService.prismic_api
  end

end
