module UserManipulation
  extend ActiveSupport::Concern

  def user_params
    params.require(:user).permit(:first_name, :last_name, :title, :phone,
                                 :company, :company_size, :email_opt_in)
  end

  def set_user_vars(resource)
    user_params.each { |k,v| resource.send("#{k}=", v) }
  end

  def add_roles(resource)
    # Hard coding role for launch, more roles to come in future
    resource.add_role(:program_admin, Program.shared_sandbox)
  end

  def delete_roles(resource)
    # This method is unecessary at the outset,
    # but will be integral to updating a user when we add more roles
    resource.current_roles(Program.shared_sandbox).each do |role|
      resource.remove_role(role, Program.shared_sandbox)
    end
  end

end
