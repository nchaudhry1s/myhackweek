require 'active_support/concern'

module Releases
  extend ActiveSupport::Concern

  def set_release
    raise Error404 if Rails.env.production?

    release_id = params[:release_id]
    release_ref = prismic.ref(release_id)

    session[:release_id] = release_ref.id if release_ref

    redirect_to params[:success_url] || request.referer
  end
end
