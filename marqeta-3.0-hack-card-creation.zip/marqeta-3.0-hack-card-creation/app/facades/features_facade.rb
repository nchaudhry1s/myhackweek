class FeaturesFacade < BaseFacade

  SERVICE_POSITIONS = ["left", "right", "center"]

  def service_position_class(position)
    if SERVICE_POSITIONS.include?(position)
      return " service-container--#{position}"
    end
  end

  def service_position(position)
    if SERVICE_POSITIONS.include?(position)
      return position
    end
    "left"
  end

  def service_id(service)
    "bbb-#{slugify(service[:service_title])}"
  end

  def blurb_medium_offset(position)
    if position == "right"
      return "medium-offset-6"
    end
    "medium-offset-1"
  end
end
