class SolutionsFacade < BaseFacade

  def feature_cards
    @data[:feature_cards] || {}
  end

end
