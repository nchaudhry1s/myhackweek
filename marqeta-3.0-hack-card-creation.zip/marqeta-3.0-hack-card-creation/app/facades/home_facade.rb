class HomeFacade < BaseFacade

  def feature_cards
    @data[:feature_cards] || {}
  end

  def solution_cards
    @data[:solution_cards] || {}
  end

end
