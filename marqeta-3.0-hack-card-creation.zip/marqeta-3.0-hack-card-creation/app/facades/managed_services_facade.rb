class ManagedServicesFacade < BaseFacade

  def features
    @data[:features].select { |v| !v[:content].nil? }
  end
end
