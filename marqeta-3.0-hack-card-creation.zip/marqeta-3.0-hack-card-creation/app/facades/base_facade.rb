class BaseFacade

  def initialize
    @data = {}
  end

  def t(key)
    @data[key]
  end

  def use_data(*datasets)
    datasets.each do |data|
      next if data.nil?
      @data.merge!(data)
    end
    self
  end

  def slugify(string)
    string.parameterize
  end

  def meta_tag_data
    {
      title: @data[:title_tag],
      description: @data[:meta_description]
    }.compact
  end

end
