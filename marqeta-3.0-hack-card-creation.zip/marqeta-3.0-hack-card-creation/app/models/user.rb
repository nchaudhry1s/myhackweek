class User < ActiveRecord::Base
  rolify

  devise :database_authenticatable,
         :registerable,
         :recoverable,
         :rememberable,
         :trackable,
         :confirmable,
         :timeoutable,
         :validatable,
         # Devise Security Extension
         :password_archivable

  has_many :user_program_records
  has_many :programs, through: :user_program_records
  has_one  :credential

  validates :email, :presence => true, :email => true
  validates :company, length: { maximum: 255 }
  validates :phone, length: { maximum: 40 }
  validates :title, length: { maximum: 128 }
  validate :password_complexity

  # Helpers
  def confirmed?
    !!confirmed_at
  end

  def current_roles(program)
    roles(program).map{ |role| role.name }
  end

  def first_login?
    sign_in_count == 1
  end

  def program_record_for(program)
    user_program_records.where(program_id: Program.where(name: program).first.id).first
  end

  def safe_app_token
    credential.present? ? credential.app_token : nil
  end

  def safe_auth_token
    credential.present? ? credential.auth_token : nil
  end

  def salesforce_create_params
    {
      state: state,
      first_name: first_name,
      last_name: last_name,
      title: title,
      phone: phone,
      email: email,
      shared_sandbox_key: safe_app_token,
      company: company,
      company_size: company_size,
      email_opt_in: !email_opt_in, # Field in reverse in SF (email_opt_out)
      id: id
    }
  end

  def salesforce_update_params
    {
      first_name: first_name,
      last_name: last_name,
      title: title,
      phone: phone,
      email: email,
      shared_sandbox_key: safe_app_token,
      current_sign_in_at: current_sign_in_at ? current_sign_in_at.to_datetime.to_s : nil, # SF preferred format
      sign_in_count: sign_in_count,
      company: company,
      company_size: company_size,
      email_opt_in: !email_opt_in, # Field in reverse in SF (email_opt_out)
      id: id
    }
  end

  # State controller
  state_machine :state, initial: :active do
    event :terminate do
      transition active: :terminated
    end
  end

  # Devise modifications
  def active_for_authentication?
    # Checks if confirmed and active
    super && self.active?
  end

  def after_database_authentication
    # Update user info after each login
    Resque.enqueue(SalesforceContactUpdateJob, self.id, "Shared Sandbox")
  end

  def inactive_message
    # Override method if not active - ie. account has been deactivated in SF
    self.active? ? super : "Sorry, this account has been deactivated."
  end

  def password_complexity
    if password.present? && !password.match(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[\W]).{8,}$/)
      errors.add :password, "must be at least eight characters long and contain one uppercase, one lowercase, one number and one special character."
    end
  end

end
