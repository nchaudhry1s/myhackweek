class PrismicBackup < ActiveRecord::Base

  def self.retrieve(id: nil, type: nil)
    date = Date.parse(PrismicStatus._date) ## date format should be day-month-year / dd-mm-yyyy
    if id
      requested_document = where(prismic_id: id).where(:created_at => date.beginning_of_day..date.end_of_day).first.prismic_object
      Marshal.load(Base64.decode64(requested_document))
    else
      requested_document = where(prismic_type: type).where(:created_at => date.beginning_of_day..date.end_of_day).map do |doc|
        requested_document = doc.prismic_object
        Marshal.load(Base64.decode64(requested_document))
      end
    end
  end

  def self.prune_db
    unless PrismicStatus.api_down?
      where("created_at <= ?", Time.zone.now.beginning_of_day - 7.days).delete_all
    end
  end

end
