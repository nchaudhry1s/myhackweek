class Mailer < Devise::Mailer
  helper :application
  include Devise::Controllers::UrlHelpers
  include Devise::Mailers::Helpers
  default template_path: 'devise/mailer'

  def post_confirmation(record, opts = {})
    devise_mail(record, :post_confirmation, opts)
  end
end
