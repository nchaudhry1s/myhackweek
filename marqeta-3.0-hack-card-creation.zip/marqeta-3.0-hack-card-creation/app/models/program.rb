class Program < ActiveRecord::Base
  resourcify

  has_many :user_program_records
  has_many :users, through: :user_program_records

  has_many :credentials

  def self.shared_sandbox
    # This will be the only program for initial 3.3 launch
    find(1)
  end
end
