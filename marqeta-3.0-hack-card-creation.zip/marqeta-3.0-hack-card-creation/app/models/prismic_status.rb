class PrismicStatus < ActiveRecord::Base

  def self.api_down?
    Rails.cache.fetch("is_the_prismic_api_currently_down_at_right_this_second_or_not", expires_in: 10.seconds) do
      first.api_down
    end
  end

  def self.api_down!(date=Time.now.strftime("%d-%m-%Y"))
    ## date format should be day-month-year / dd-mm-yyyy
    obj = first
    obj.api_down = true
    obj.date = date
    obj.save
  end

  def self.api_up!
    obj = first
    obj.api_down = false
    obj.save
  end

  def self._date
    first.date
  end

end
