class Ability
  include CanCan::Ability

  # Need a way to determine current program in the future

  def initialize(user)
    alias_action :create, :read, :update, :destroy, :to => :crud

    if user.has_role? :program_admin, Program.shared_sandbox
      can :crud, User
    end
  end
end
