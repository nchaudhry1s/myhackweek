class TwitterService
  CONFIG = {}
  def self.init_twitter 
    if CONFIG.empty?
      self.init_config
    end
    twitter = Twitter::REST::Client.new do |config|
      config.consumer_key = TwitterService::CONFIG[:consumer_key]
      config.consumer_secret = TwitterService::CONFIG[:consumer_secret]
      config.access_token = TwitterService::CONFIG[:access_token]
      config.access_token_secret = TwitterService::CONFIG[:access_token_secret]
    end
  end

  def self.init_config
    twitter_config = YAML.load(ERB.new(File.read(Rails.root + "config/settings.yml")).result).with_indifferent_access
    TwitterService::CONFIG[:consumer_key] = twitter_config[:twitter][:consumer_key] 
    TwitterService::CONFIG[:consumer_secret] = twitter_config[:twitter][:consumer_secret]
    TwitterService::CONFIG[:access_token] = twitter_config[:twitter][:access_token]
    TwitterService::CONFIG[:access_token_secret] = twitter_config[:twitter][:access_token_secret]
  end
end 
