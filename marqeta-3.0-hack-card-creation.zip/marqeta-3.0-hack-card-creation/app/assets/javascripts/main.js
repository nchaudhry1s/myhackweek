$(function(){
  $(document).foundation({
    reveal: {
      animation: 'fade',
      animation_speed: 100
    },
    abide: {
      live_validate: false,
      validators: {
        'required-select': function(el) {
          var hasValue = $(el).val() && true || false;
          return hasValue;
        }
      },
      patterns: {
        strongPassword: /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[\W]).{8,}$/,
        fortyCharMax: /^.{0,40}$/,
        oneTwentyEightCharMax: /^.{0,128}$/,
        twoFiftyFiveCharMax: /^.{0,255}$/
      }
    }
  });
});
