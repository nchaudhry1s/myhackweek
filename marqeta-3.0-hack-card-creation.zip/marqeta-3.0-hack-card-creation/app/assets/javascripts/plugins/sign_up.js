;$(function() {
  $('.sign_up_password').focus(function() {
    if(!localStorage["alerted"]) {
      buildNoty({message: 'Password must be at least eight characters long and contain one uppercase, one lowercase, one number and one special character.', name: 'error'});
      localStorage["alerted"] = true
    };
  });
});
