;$(function() {

  function buildSwaggerUI(spec) {
    var swaggerUi = new SwaggerUi({
      url: '',
      spec: spec,
      dom_id: 'api-explorer',
      docExpansion: 'none',
      validatorUrl: null,
      defaultModelRendering: 'model',
      apisSorter: 'alpha',
      authorizations: {
        key: new SwaggerClient.ApiKeyAuthorization("Authorization", 'Basic ' + gon.swagger_auth, "header")
      },
      onComplete: function() {
        var $button = $('.sandbox_header input[type="submit"]');
        $button.val('Submit request');
        $('#api-explorer-spinner').remove();
        $button.on('click', function() {
          var
            $this = $(this),
            $operation = $this.closest('.operation'),
            endpointString = $operation.find('.path > a').html(),
            endpointSlashless = _.trimLeft(endpointString, '/'),
            endpoint = encodeURIComponent(endpointSlashless),
            method = $operation.find('.http_method > a').html(),
            pageviewPath = '/api-explorer/' + endpoint + '/' + method
          ;
          ga('send', 'pageview', pageviewPath);
        });
        if (!_.has(gon, 'swagger_auth')) {
          $button.prop('disabled', true)
          $('.sandbox_header').append('<a href="/users/sign_up?ae_id=2" class="sign-up-button">Sign up now &gt;</a>');
        }
      }
    });
    swaggerUi.load();
  }

  if ($('#api-explorer').size()) {
    var headerParams = {};
    if (gon.auth_swagger) {
      headerParams['Authorization'] = 'Basic ' + gon.swagger_auth;
    }
    $.ajax({
      url: 'https://' + gon.swagger_domain + '/v3/swagger.json',
      headers: headerParams,
      success: function(response) {
        var
          spec = _.cloneDeep(response),
          cleanUpWidget = (function(method) {
            return function() {
              var
                $widget = ('#'+domId),
                $button = $('.sandbox_header input[type="submit"]', $widget),
                $operation = $('.operation', $widget),
                endpointString = $operation.find('.path > a').html(),
                endpointSlashless = _.trimLeft(endpointString, '/'),
                endpoint = encodeURIComponent(endpointSlashless),
                method = $operation.find('.http_method > a').html(),
                pageviewPath = '/api-explorer-widget/' + endpoint + '/' + method
              ;
              $button.val('Submit request');
              $button.on('click', function() {
                ga('send', 'pageview', pageviewPath);
              });
              $('.operation-params .snippet-link', $widget).click();
              if (_.contains(['post', 'put'], method)) {
                $('.body-textarea', $widget).show();
                $('.editor_holder', $widget).hide();
              }
            }
          })()
        ;
        _.each(spec.paths, function(endpoints) {
          _.each(endpoints, function(method) {
            delete method.security
            method.tags = _.map(method.tags, function(tag) {
              var
                newTag = tag
                colonIndex = newTag.indexOf(':')
              ;
              if (colonIndex !== -1) {
                newTag = newTag.substring(0, colonIndex);
              }
              newTag = newTag.replace(/^v3/, '');
              newTag = _.trim(newTag);
              return newTag;
            });
          });
        });
        spec.schemes = ['https'];
        spec.host = gon.swagger_domain;
        buildSwaggerUI(spec);
      }
    });
  }

});
