;$(function() {
  var
    $gradient = $('[data-pin-gradient-top]'),
    $frame = $('.gradient-top-frame'),
    $header = $('header'),
    pinGradient = function() {
      var offset = $frame.offset();
      $gradient.css({
        right: Math.min(0, -$('body').width() + offset.left + $frame.width()),
      });
    }
  ;
  if ($gradient.size() && $frame.size()) {
    $(window).on('resize', pinGradient);
    pinGradient();
  }
});
