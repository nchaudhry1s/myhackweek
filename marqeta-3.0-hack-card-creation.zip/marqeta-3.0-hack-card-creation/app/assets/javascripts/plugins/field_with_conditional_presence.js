$(function() {
  $('[data-has-conditional-fields]').each(function() {
    var $select = $(this);
    $select.on('change', function() {
      var
        $options = $select.find('option'),
        $option = $options.filter(':selected'),
        fieldToShowSelector = $option.data('show-field-when-selected'),
        hideFieldsSelector = $options.filter('[data-show-field-when-selected]').map(function() {
          return $(this).data('show-field-when-selected');
        }).toArray().join(',')
      ;
      $(hideFieldsSelector).hide();
      if (fieldToShowSelector) {
        $(fieldToShowSelector).show();
      }
    });
  });
});
