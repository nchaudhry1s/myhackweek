;$(function() {
  $('[data-reveal-token]').each(function(i,e) {
    $(e).on('click', function(el) {
      if (Foundation.utils.is_medium_up()) {
        var id = $(this).data('reveal-token');
        $('#'+id).foundation('reveal', 'open');
      }
    });
  });
});
