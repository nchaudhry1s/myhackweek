;$(function() {
  var flashNameNotyType = {
    alert: 'alert',
    error: 'error',
    notice: 'success'
  };
  var buildNoty = function(notyObj) {
    var
      message = notyObj.message,
      messageMs = message.length * 70,
      minDuration = Math.max(messageMs, 3000),
      messageDuration = Math.min(minDuration, 7000)
    ;
    noty({
      animation: {
        open: 'animated bounceInDown',
        close: 'animated fadeOutUpBig'
      },
      layout: 'top',
      text: message,
      theme: 'marqeta',
      timeout: messageDuration,
      type: flashNameNotyType[notyObj.name]
    })
  };
  window.buildNoty = buildNoty;
  _.each(window.notys, buildNoty);
});
