;$(function() {
  $('.carousel-card').on ('click', function(e) {
    if (!$(e.target).is('a')) {
      var url = $(e.currentTarget).find('.header a').attr('href');
      window.open(url, '_blank');  
    }
  })
});

