;$(function() {
  $('[data-follow-scroll]').each(function(i,e) {
    var
      $w = $(window),
      $wrap = $(e),
      followerInitialOffset = $wrap.offset().top,
      topbarHeight = 75,
      topBottomMargins = 45,
      offsetTop = topbarHeight + topBottomMargins, // distance sidebar is from topbar
      distanceFromTop = 0,
      footerHeight = $('footer').height(),
      footerTop = $(document).height() - footerHeight,
      $wrap, windowTop, windowBottom, followerHeight,
      followerTop, followerBottom, followerBottomPosition
    ;
    $w.on('scroll', function() {
      windowHeight = $w.height();
      windowTop = $w.scrollTop();
      windowBottom = windowTop + windowHeight;
      followerHeight = $wrap.outerHeight();
      followerTop = $wrap.offset().top;
      followerBottom = followerTop + followerHeight;
      if (footerTop < windowBottom) {
        // position bottom of nav at top of footer (with the topBottomMargin)
        //distanceFromTop = $(document).height() - footerHeight - ...;
      } else if (windowHeight > followerHeight || windowTop + followerInitialOffset < followerTop) {
        distanceFromTop = Math.max(windowTop, 0);
      } else if (windowBottom > followerBottom + topBottomMargins) {
        distanceFromTop = windowBottom - followerHeight - followerInitialOffset - topBottomMargins;
      } // else scroll as usual
      $wrap.css({'top': distanceFromTop+'px'});
    });
  });
});
