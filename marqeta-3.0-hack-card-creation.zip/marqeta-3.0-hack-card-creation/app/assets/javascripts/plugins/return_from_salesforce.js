;$(function() {
  if (window.location.hash === '#thank-you') {
    $('#thank-you-wrap').show();
    $('#contact-form-wrap').hide();
    if (history.replaceState) {
      setTimeout(function() {
        history.replaceState(null, null, window.location.pathname);
      }, 1000);
    }
  }
});
