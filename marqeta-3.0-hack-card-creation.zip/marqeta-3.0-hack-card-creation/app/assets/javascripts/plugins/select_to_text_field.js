;$(function() {
  /// This plugin takes the value from a dropdown and applies it to a text field
  $('[data-select-input-transfer]').each(function() {
    $(this).on('change', function() {
      var
        $select = $(this),
        $option = $select.find('option:selected'),
        selector = $select.data('transfer-to'),
        value = $select.val(),
        transferValue = $option.data('transfer-value'),
        valueToTransfer = _.isUndefined(transferValue) ? value : transferValue
      ;
      $(selector).val(valueToTransfer);
    })
  });
});
