;$(function() {
  $('[data-start-disabled]').on('change', function() {
    $(this).removeAttr('data-start-disabled');
  });
});
