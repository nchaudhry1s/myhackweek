;$(function() {
  var
    hasLevel3 = $('.level-3').size(),
    $subnav = hasLevel3 ? $('.level-3') : $('.level-2')
  ;
  $subnav.find('> li > a').each(function(i,e) {
    var href = $(e).attr('href');
    if (href.charAt(0) !== '#')
      return;
    new Waypoint({
      element: $(href)[0],
      offset: 15,
      handler: function(direction) {
        if (direction === 'up') {
          var
            $current = $subnav.find('> li > a[href=#'+this.element.id+']'),
            $prev = $current.parent().prev()
          ;
          if ($prev.size()) {
            $subnav.find('.active').removeClass('active');
            $prev.find('> a').addClass('active');
          }
        } else {
          $subnav.find('.active').removeClass('active');
          $subnav.find('> li > a[href=#'+this.element.id+']').addClass('active');
          window.history.replaceState({}, '', '#'+this.element.id);
        }
      }
    });
  });
});
