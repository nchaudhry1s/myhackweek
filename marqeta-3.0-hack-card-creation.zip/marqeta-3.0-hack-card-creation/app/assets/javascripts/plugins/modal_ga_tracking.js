;$(function() {
  $('[data-reveal]').on('open.fndtn.reveal', function () {
    var page = $(this).data('pageview-value');
    if (page) {
      ga('send', 'pageview', page);
    }
  });
  $('#edit-my-profile').on('click', function() {
    ga('send', 'pageview', '/users/_my_profile/edit');
  });
});
