;$(function() {
  $('[data-slick]').slick();
});
