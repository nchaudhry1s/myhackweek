;$(function(){
  $('p.code').each(function(i, block) {
    hljs.highlightBlock(block);
  });
});

