;$(function() {
  var $dropdown = $("#release_list");
  $(".current_release" ).click(function() {
    if ($dropdown.is(":visible")) {
      $dropdown.hide();
      localStorage['show-releases'] = true;
    } else {
      $dropdown.show();
      localStorage['show-releases'] = false;
    }
  });
});
