;$(function() {
  $('[data-set-modal-state]').click(function() {
    var
      $this = $(this),
      state = $this.data('set-modal-state'),
      $modal = $this.closest('.reveal-modal')
    ;
    $modal.attr('data-state', state);
    $modal.on('close.fndtn.reveal', function() {
      $modal.attr('data-state', '');
    });
  });
});
