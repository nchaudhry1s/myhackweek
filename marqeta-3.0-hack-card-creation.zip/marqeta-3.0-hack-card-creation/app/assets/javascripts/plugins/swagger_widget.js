;$(function() {
  if (_.has(gon, 'swagger_auth')) {
    var apis = $('[data-swagger]').map(function() {
      return $(this).data('api');
    });

    _.each(_.uniq(apis), function(api) {
      if (_.isEmpty(api)) {
        return;
      }
      $.ajax({
        url: 'https://' + gon.swagger_domain + '/v3/swagger.json',
        success: function(response) {
          $('[data-swagger][data-api="'+api+'"]').each(function() {
            var
              domId = $(this).attr('id'),
              endpoint = $(this).data('endpoint'),
              method = $(this).data('method'),
              spec = _.cloneDeep(response),
              cleanUpWidget = (function(method) {
                return function() {
                  var
                    $widget = ('#'+domId),
                    $button = $('.sandbox_header input[type="submit"]', $widget),
                    $operation = $('.operation', $widget),
                    endpointString = $operation.find('.path > a').html(),
                    endpointSlashless = _.trimLeft(endpointString, '/'),
                    endpoint = encodeURIComponent(endpointSlashless),
                    method = $operation.find('.http_method > a').html(),
                    pageviewPath = '/api-explorer-widget/' + endpoint + '/' + method
                  ;
                  $button.val('Submit request');
                  $button.on('click', function() {
                    ga('send', 'pageview', pageviewPath);
                  });
                  $('.operation-params .snippet-link', $widget).click();
                  if (_.contains(['post', 'put'], method)) {
                    $('.body-textarea', $widget).show();
                    $('.editor_holder', $widget).hide();
                  }
                }
              })(method)
            ;
            if (spec.swaggerVersion === '1.2') {
              var matchingEndpoints = _.filter(spec.apis, function(api) {
                return api.path === endpoint;
              });
              if (_.isEmpty(endpoint)) {
              } else if (matchingEndpoints.length > 0) {
                spec.apis = matchingEndpoints;
                spec.apis[0].operations = _.filter(spec.apis[0].operations, function(op) {
                  return op.method === method.toUpperCase();
                });
              } else if (matchingEndpoints.length === 0) {
                return;
              }
              _.each(spec.models, function(model) {
                model.subTypes = [];
              });
              spec = SwaggerConverter.convert(spec, spec);
              _.each(spec.paths, function(endpoints) {
                _.each(endpoints, function(method) {
                method.tags = [_.kebabCase(method.summary)]
                });
              });
              delete spec.info
              spec.schemes = ['https'];
              spec.host = gon.swagger_domain + ':443';
            } else {
              spec.paths = _.pick(spec.paths, endpoint);
              spec.paths[endpoint] = _.pick(spec.paths[endpoint], method);
              _.each(spec.paths, function(endpoints) {
                _.each(endpoints, function(method) {
                method.tags = [_.kebabCase(method.summary)]
                });
              });
              spec.schemes = ['https'];
              spec.host = gon.swagger_domain;
            }
            buildSwaggerUI(domId, spec, cleanUpWidget);
          });
        }
      });
    });
    function buildSwaggerUI(domId, spec, onComplete) {
      var swaggerUi = new SwaggerUi({
        url: '',
        spec: spec,
        dom_id: domId,
        docExpansion: 'list',
        validatorUrl: null,
        defaultModelRendering: 'model',
        authorizations: {
          key: new SwaggerClient.ApiKeyAuthorization("Authorization", 'Basic ' + gon.swagger_auth, "header")
        },
        onComplete: onComplete
      });
      swaggerUi.load();
    }
  } else {
    $('[data-swagger]').each(function() {
      var
        bcData = $(this).attr('data-bc-id'),
        cpData = $(this).attr('data-cp-id')
        bcId = _.has(gon.button_copy, bcData) ? bcData : "1",
        cpId = _.has(gon.cta_copy, cpData) ? cpData : "1",
        template_params = {
          bcId: bcId,
          cpId: cpId,
          buttonCopy: gon.button_copy[bcId],
          bannerCopy: gon.cta_copy[cpId]
        },
        banner = _.template(' \
          <div class="cta-banner clearfix"> \
            <div class="cta-banner-gradient" data-pin-gradient-cta></div> \
            <a class="white skeleton button" href="/users/sign_up?cp_id=<%= cpId %>&bc_id=<%= bcId %>"> \
              <%= buttonCopy %> &gt; \
            </a> \
            <div class="banner-copy-wrap"> \
              <div class="banner-copy-cell"> \
                <div class="banner-copy"><%= bannerCopy %></div> \
              </div> \
            </div> \
          </div> \
        ')(template_params)
      ;
      $(this).append(banner);
    });
    pinCtaBannerGradients();
  }
});
