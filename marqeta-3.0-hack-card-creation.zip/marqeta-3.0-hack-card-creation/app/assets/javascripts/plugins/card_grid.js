;$(function() {
  $('[data-card-grid] .header').on('click', function(e) {
    if (Foundation.utils.is_medium_up()) {
      return;
    }
    var
      $currentTarget = $(e.currentTarget),
      $wrap = $currentTarget.closest('.card-wrap'),
      is_expanded = $wrap.hasClass('expanded')
    ;
    $('[data-card-grid] .expanded').removeClass('expanded');
    if (!is_expanded) {
      $wrap.addClass('expanded');
    }
  });

  if (Foundation.utils.is_small_only()) {
    return;
  }

  var cardsPerRow = 1;
  if (Foundation.utils.is_medium_only()) {
    cardsPerRow = 3;
  } else if (Foundation.utils.is_large_up()) {
    cardsPerRow = 4;
  }

  var
    cardCount = $('[data-card-grid] .card-wrap').size(),
    leftOver = cardCount % cardsPerRow,
    overhang = cardCount - cardsPerRow - 1,
    cliff = cardsPerRow - leftOver,
    base = cardCount - cardsPerRow,
    mPurple = '#791ddc',
    mDarkGrey = '#2d2d2d'
  ;

  var $invert = $('[data-card-grid] .card-inner-wrap:gt('+overhang+'):lt('+cliff+')').parent();
  var $baseFloor = $('[data-card-grid] .card-inner-wrap:gt('+base+'):lt('+leftOver+')').parent();

  $invert.css('border-bottom', '1px solid '+mDarkGrey);
  $invert.each(function(i,el) {
    $(el).hover(function(e) {
      $(e.currentTarget).css('border-bottom', '3px solid '+mPurple);
    }, function(e) {
      $(e.currentTarget).css('border-bottom', '1px solid '+mDarkGrey);
    });
  });

  $baseFloor.css('border-bottom', '1px solid '+mDarkGrey);
  $baseFloor.each(function(i,el) {
    $(el).hover(function(e) {
      $(e.currentTarget).css('border-bottom', '3px solid '+mPurple);
    }, function(e) {
      $(e.currentTarget).css('border-bottom', '1px solid '+mDarkGrey);
    });
  });
});
