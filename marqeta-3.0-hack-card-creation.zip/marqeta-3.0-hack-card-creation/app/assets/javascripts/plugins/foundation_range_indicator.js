;$(function() {
  var $indicator = $('#foundation-range-indicator');
  if ($indicator.length) {
    var
      range, previousRange, $currentRange, timeout,
      showIndicator = Foundation.utils.throttle(function(e){
        if (Foundation.utils.is_small_only())   { range = "small" } else
        if (Foundation.utils.is_medium_only())  { range = "medium" } else
        if (Foundation.utils.is_large_only())   { range = "large" } else
        if (Foundation.utils.is_xlarge_only())  { range = "xlarge" } else
        if (Foundation.utils.is_xxlarge_only()) { range = "xxlarge" }
        if (range !== previousRange) {
          previousRange = range;
          $currentRange = $indicator.find('.'+range);
          $indicator.children().hide();
        }
        $currentRange.show();
        if (timeout) {
          clearTimeout(timeout);
        }
        timeout = setTimeout(function() {
          $currentRange.hide();
        }, 3000);
      }, 500)
    ;
    $(window).on('resize', showIndicator);
    showIndicator();
  }
});
