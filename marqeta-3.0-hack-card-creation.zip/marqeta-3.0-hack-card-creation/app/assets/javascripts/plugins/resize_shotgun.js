function pullForResize(pelletCount, interval) {
  if (pelletCount) {
    $(window).trigger('resize');
    setTimeout(
      function() { pullForResize(pelletCount - 1, interval); },
      interval
    );
  }
}
