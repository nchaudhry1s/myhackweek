;$(function() {
  window.pinCtaBannerGradients = function() {
    var
      $gradients = $('[data-pin-gradient-cta]'),
      $mainContent = $('[data-cta-banner-container]')
    ;
    $gradients.each(function() {
      var
        $this = $(this),
        $banner = $this.closest('.cta-banner')
        mainContentOffset = $mainContent.offset(),
        bannerOffset = $banner.offset()
      ;
      $(this).css({
        left: mainContentOffset.left - bannerOffset.left,
        right: -$('body').width() + bannerOffset.left + $banner.width(),
      });
    });
  };
  $(window).on('resize', pinCtaBannerGradients);
  pinCtaBannerGradients();
});
