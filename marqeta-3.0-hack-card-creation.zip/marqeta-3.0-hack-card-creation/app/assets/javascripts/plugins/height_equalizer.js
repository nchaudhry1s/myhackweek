;$(function() {
  $('[data-equalize-heights]').each(function() {
    var
      containerSelector = $(this).data('scaling-container'),
      equalizeSelector = $(this).data('equalize-heights'),
      isolateSelector = $(this).data('isolate')
    ;
    if (!containerSelector) return;
    var
      $scalingContainer = $(containerSelector),
      $clone = $scalingContainer.clone(),
      measureAndSet = function() {
        $equalizeThese = $scalingContainer.find(equalizeSelector);
        $measureThese = $clone.find(equalizeSelector);
        $heights = $measureThese.map(function() { return $(this).height(); });
        maxHeight = Math.max.apply(null, $heights);
        $equalizeThese.height(maxHeight);
      }
    ;
    if (isolateSelector) {
      $clone.empty();
      $scalingContainer.find(isolateSelector).each(function() {
        var $thisClone = $(this).clone();
        $clone.append($thisClone);
      });
    }
    $clone.addClass('height-equalizer-clone');
    $scalingContainer.after($clone);
    $(window)
      .on('resize', Foundation.utils.throttle(measureAndSet, 50))
      .on('orientationchange', Foundation.utils.throttle(measureAndSet, 50))
    ;
    measureAndSet();
    setTimeout(measureAndSet, 500);
    $(document).on('open.fndtn.reveal', '[data-reveal]', function() {
      setTimeout(measureAndSet, 200);
    });
  });
});
