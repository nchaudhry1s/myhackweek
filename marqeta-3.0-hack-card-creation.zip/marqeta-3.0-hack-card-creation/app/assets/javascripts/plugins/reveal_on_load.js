;$(function() {
  $('.reveal-on-load').foundation('reveal', 'open');
});

