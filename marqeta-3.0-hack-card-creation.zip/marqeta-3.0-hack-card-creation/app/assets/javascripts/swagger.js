//  SWAGGER UI
//= require jquery.browser/dist/jquery.browser.js
//= require swagger-ui/dist/lib/jquery.slideto.min.js
//= require swagger-ui/dist/lib/jquery.wiggle.min.js
//= require swagger-ui/dist/lib/jquery.ba-bbq.min.js
//= require swagger-ui/dist/lib/handlebars-4.0.5.js
//= require swagger-ui/dist/lib/backbone-min.js
//= require swagger-ui/dist/swagger-ui.js
//= require swagger-ui/dist/lib/jsoneditor.min.js
//= require swagger-ui/dist/lib/marked.js
//
//= require swagger-converter/browser.js
