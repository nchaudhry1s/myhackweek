module ManagedServicesHelper

  def get_features_grid_class
    size = get_column_size
    "medium-#{size} large-#{size}"
  end

  def get_column_size
    (GlobalConstants::GRID_COLUMNS/@facade.features.length).floor
  end

end
