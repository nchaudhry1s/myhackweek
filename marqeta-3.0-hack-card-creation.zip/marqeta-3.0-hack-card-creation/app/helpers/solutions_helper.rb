module SolutionsHelper

  def render_logos(logos)
    if logos.present?
      render partial: "shared/logos", locals: { logos: logos }
    end
  end

  def render_hero_footer_buttons(see_guide_link)
    if see_guide_link.present?
      render partial: "solutions/hero_footer_buttons",
             locals: { see_guide_link: see_guide_link }
    end
  end
end
