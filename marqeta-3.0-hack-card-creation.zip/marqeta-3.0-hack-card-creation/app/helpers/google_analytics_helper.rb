module GoogleAnalyticsHelper
  def dimension1
    current_user.id
  end

  def dimension2
    user_program_record = current_user.user_program_records.first
    if user_program_record.present?
      user_program_record.salesforce_contact_id
    end
  end
end
