module PagesHelper

  def dropdown_arrow
    render 'svgs/dropdown_arrow'
  end

  def get_content_with_table(document, type)
    html = %()
    if @content = table_tag(document, type)
      @content.each do |text|
        html += text
      end
    end
    html.html_safe
  end

  def get_next_page(page, pages, link)
    pages.each_with_index{ |item, index|
      if index < pages.length - 1
        if page.id == item.id
          page_data = pages[index + 1]
          return yield(page_data.first_title, link.link_to(page_data))
        end
      else
        return nil
      end
    }
  end

  def cstudies?
    @document.type == "cstudies"
  end

  def first_login?
    !!params[:intro_flow]
  end
end
