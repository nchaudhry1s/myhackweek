module ApplicationHelper
  include FutureReleasesHelper
  include GoogleAnalyticsHelper
  include Twitter::Autolink
  require 'twitter-text'

  def twitter_rate_limit(i)
    num_attempts = 0
    begin
      num_attempts += 1
      marqeta_tweets = TwitterService.init_twitter
      marqeta_tweets.favorites("marqeta", count: i).collect
    rescue Twitter::Error::TooManyRequests => error
      if num_attempts <= 3
        sleep error.rate_limit.reset_in
        retry
      else
        raise
      end
    rescue Twitter::Error => error
      Rails.logger.error("Twitter Error: #{error.message}")
      return []
    end
  end

  def twitter_text(text)
    text = auto_link(text, :target => '_blank')
    text ? text.html_safe : ''
  end

  def twitter_live(i)
    tweets = []
    tweet_id = nil
    twitter_rate_limit(i).collect.each do |tweet|
      if tweet
        tweet_id = tweet.id.to_s
        user_name = tweet.user.screen_name
        tweet_url = tweet.url
        text = tweet.text
        tweets << {
          user_name: user_name,
          tweet_url: tweet_url,
          text: text
        }
      end
    end
    @tweets_cache_key = tweet_id ? "twitter" + tweet_id + ref.to_s : nil
    yield(tweets)
  end

  def ga_token
    if Rails.env.production?
      "UA-24017773-33"
    elsif Rails.env.qa?
      "UA-24017773-34"
    else
      "UA-24017773-35"
    end
  end

  def job_board
    if Rails.env.production?
      "marqeta"
    else
      "marqetatest"
    end
  end

  def use_responsive_layout?
    return true unless ['references', 'guides', 'api_explorer'].include?(controller_name)
  end

  def solutions_page_link(page_id)
    solutions_page_path(id: page_id)
  end

  def insert_meta_tags_here
    if @facade.present? && @facade.meta_tag_data.present?
      title = @facade.meta_tag_data[:title]
      description = @facade.meta_tag_data[:description]
      display_meta_tags(
        site: 'Marqeta',
        separator: '-',
        reverse: true,

        charset: 'utf-8',
        title: title,
        description: description,
        canonical: request.original_url,
        icon: [
          {
            href: image_url('favicon-32px.ico'),
            sizes: '32x32'
          },
          {
            href: image_url('favicon-24px.ico'),
            sizes: '24x24'
          },
          {
            href: image_url('favicon-16px.ico'),
            sizes: '16x16'
          }
        ],
        og: {
          site_name: 'Marqeta',
          type: 'website',
          locale: 'en_US',
          url: request.original_url,
          title: title,
          description: description,
          image: [
            {
              _: image_url('social_image1.png')
            },
            {
              _: image_url('social_image2.png')
            },
            {
              _: image_url('social_image3.png')
            }
          ]
        },
        twitter: {
          card: 'summary',
          aite: '@Marqeta',
          url: request.original_url,
          title: title,
          description: description
        }
      )
    end
  end

  def current_user_company_size
    GlobalConstants::COMPANY_SIZE_OPTIONS.key(current_user.company_size)
  end

  def current_user_full_name
    "#{current_user.first_name} #{current_user.last_name}"
  end

  def current_user_initials
    "#{current_user.first_name[0]}#{current_user.last_name[0]}"
  end

  def current_user_email
    "#{current_user.email}"
  end

  def safe_user_app_token
    current_user.safe_app_token
  end

  def safe_user_auth_token
    current_user.safe_auth_token
  end

  def environment_base_url
    "https://#{Marqeta30.config[:swagger][:payments_host]}/v3/"
  end

  def page_got_swagger?
    %w(references guides api_explorer).include?(controller_name)
  end

  def update_error
    "reveal-on-load" if flash[:password_update_error]
  end

  def retina_image_tag(asset_name, options={})
    dir_lambda = lambda { |dirname| "#{dirname}/" unless dirname == "." }
    dir_name = dir_lambda.call(File.dirname(asset_name))
    ext_name = File.extname(asset_name)
    base_name = File.basename(asset_name, ext_name)
    retina_asset_name = "#{dir_name}#{base_name}@2x#{ext_name}"

    image_tag(asset_name, options.merge('data-interchange' => "[#{asset_path(retina_asset_name)}, (retina)]"))
  end

end
