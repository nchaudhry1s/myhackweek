module BannerHelper

  BANNER_ALIGNMENTS = [ "center", "left", "right"]

  def apply_pull_7_for_impact_right(banner_alignment)
    apply_directional_modification("pull", 7, banner_alignment)
  end

  def apply_push_6_for_impact_right(banner_alignment)
    apply_directional_modification("push", 6, banner_alignment)
  end

  def banner_alignment_class(desired_alignment)
    if BANNER_ALIGNMENTS.include?(desired_alignment)
      return "#{desired_alignment}-impact-banner"
    end
  end

  def render_banners(banners)
    acceptable_banners = banners.reject { |banner| banner[:title].blank? }
    render partial: "solutions/banner", collection: acceptable_banners
  end

  def this_text_group_all_impact(banner_alignment)
    if banner_alignment != "center"
      apply_to_all_impact(6)
    end
  end

  def this_img_group_all_impact(banner_alignment)
    if banner_alignment != "center"
      apply_to_all_impact(5)
    end
  end

  private

  def apply_to_all_impact(units)
     modification = "-#{units}"
    "medium#{modification} large#{modification} xlarge#{modification}"
  end

  def apply_directional_modification(direction, units, banner_alignment)
    if direction.present? && units.present? && banner_alignment == "right"
      modification = "-#{direction}-#{units}"
      "medium#{modification} large#{modification} xlarge#{modification}"
    end
  end
end
