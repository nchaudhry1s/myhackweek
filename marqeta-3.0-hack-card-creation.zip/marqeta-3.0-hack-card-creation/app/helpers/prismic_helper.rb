module PrismicHelper

  def api_guides_link()
    @api_guides_link ||= Prismic::LinkResolver.new(nil) {|doc| api_guide_path(id: doc.id, slug: doc.slug)}
  end

  def api_guides_path
    CmsService.new(id: 'WIlA2isAAMkAsk6F', ref: ref).retrieve
  end

  def get_categoryies
    @categories = get_order(CmsService.new(type: 'category', ref: ref).retrieve)
    @categories.nil? ? nil : @categories
  end

  def get_content(document)
    document[document.type+'.content'].nil? ? nil
    : document[document.type+'.content'].as_html(link_resolver()).html_safe
  end

  def get_image(document)
    document[document.type+'.image'].nil? ? nil : document[document.type+'.image'].main.url
  end

  def get_intro(document)
    document[document.type+'.intro'].nil? ? nil
    : document[document.type+'.intro'].as_html_safe(references_docs_link())
  end

  def guides_page_link
    @guides_page_link ||= api_guides_link().link_to(api_guides_path)
  end

  # For a given document, describes its URL on your front-office.
  # You really should edit this method, so that it supports all the document types your users might link to.
  # Beware: doc is not a Prismic::Document, but a Prismic::Fragments::DocumentLink,
  # containing only the information you already have without querying more (see DocumentLink documentation)
  def link_resolver()
    @link_resolver ||= #Prismic::LinkResolver.new(nil) {|doc| document_path(id: doc.id, slug: doc.slug)}
      Prismic.link_resolver('master'){ |doc_link| "#{request.original_url}/#{doc_link.id}/#{doc_link.slug}" }
      # maybe_ref is not expected by document path, so it appends a ?ref=maybe_ref to the URL;
      # since maybe_ref is nil when on master ref, it appends nothing.
      # You should do the same for every path method used here in the link_resolver and elsewhere in your app,
      # so links propagate the ref id when you're previewing future content releases.
  end

  # Return the set reference
  def maybe_ref
    @maybe_ref ||= (params[:ref].blank? ? nil : params[:ref])
  end

  def preview_link()
    potential_path = { "ref" => "docs", "guide" => "guides"}
    # You must add key value pairs below whenever we "prismicize" a page
    special_path   = {
      "VxpRZyYAAMkbmPJi" => "",
      "Vx4uoSYAAJxhr_Sw" => "about",
      "Vx4wASYAAJhhr_y-" => "careers",
      "WVF9JyYAACxJjIZM" => "contact",
      "WVK16SYAAE5Ykejc" => "culture",
      "WVGggSYAAKFJjSIU" => "features",
      "WV2BOiEAACMAK5R8" => "solutions/delivery",
      "WWAITiEAAFIyNrGq" => "solutions/disburse",
      "WWAIGSEAAEgvNrDC" => "solutions/expense",
      "WWAHZiEAAFIyNq2n" => "solutions/lend",
      "WWAH5SEAAFIyNq_c" => "solutions/virtual",
      "VhxVERwAAOAA-1x1" => "api-terms",
      "VhxjARwAAOAA-7Bf" => "privacy/safeharbor",
      "WVU92CYAAIRznQ5a" => "managed-services/program-dashboard",
      "VhxUNhwAAN4A-1c9" => "terms"
    }
    @link_resolver ||= Prismic.link_resolver('master') do |doc_link|
      if special_path[doc_link.id]
        File.join(root_path, special_path[doc_link.id])
      else
        File.join(root_path, potential_path[doc_link.type], doc_link.id, doc_link.slug)
      end
    end
  end

  # Return the actual used reference
  def ref
    return if PrismicStatus.api_down?
    @ref ||= maybe_ref || @prismic.master_ref
  end

  def refs_categorized(documents, category)
    @parts = documents.partition { |doc| doc['ref.category'].nil? || get_title(doc).nil? }
    @parts.last.find_all{|doc| doc['ref.category'].id == category.id }
  end

  def references_docs_link()
    @references_doc_link ||= Prismic::LinkResolver.new(nil) {|ref| references_doc_path(id: ref.id, slug: ref.slug)}
  end

  def reference_docs_path
    CmsService.new(id: 'ViBKPB0AAMIA4Axf', ref: ref).retrieve
  end

  def references_page_link
    @references_page_link ||= references_docs_link().link_to(reference_docs_path)
  end

  def table_tag(document, type)
    serializer = Prismic.html_serializer do |element, html|
      if element.is_a?(Prismic::Fragments::StructuredText::Block::Paragraph) && (element.label == "markdown")
        markdown = Redcarpet::Markdown.new(Redcarpet::Render::HTML.new, autolink: true, tables:
 true)
        %(<div class="table-wrapper">#{markdown.render("#{element.as_text}")}</div>)
      elsif element.is_a?(Prismic::Fragments::StructuredText::Block::Paragraph) && (element.label == "swagger-widget")
        begin
          widget_data = JSON.parse(element.text)
        rescue JSON::ParserError
          next ""
        end
        dom_id = "swagger-widget-#{element.object_id}"
        api = widget_data["api"]
        endpoint = widget_data["endpoint"]
        method = widget_data["method"]
        bc_id = widget_data["bc_id"]
        cp_id = widget_data["cp_id"]
        %(
          <div class="row swagger-section">
            <div
              id="#{dom_id}"
              data-swagger
              data-api="#{api}"
              data-endpoint="#{endpoint}"
              data-method="#{method}"
              data-bc-id="#{bc_id}"
              data-cp-id="#{cp_id}"
              class="swagger-ui-wrap small-12 column"
            ></div>
          </div>
        )
      else
        nil
      end
    end
    document[type].nil? ? nil
    : document[type].as_html(references_docs_link(), serializer).split('#table')
  end

end
