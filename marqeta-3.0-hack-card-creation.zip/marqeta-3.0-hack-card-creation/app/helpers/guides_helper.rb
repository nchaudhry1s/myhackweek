module GuidesHelper
  def get_api_content(document)
    sections = []
    (1..100).each do |i|
      title = document[document.type+'.sec' + i.to_s + '_title']
      next if title.nil?
      title = title.as_text
      slug = title.gsub(/[^a-zA-Z]/, '_').downcase
      content = get_content_with_table(document, document.type+'.sec'+i.to_s+'_content')
      sections << {
        title: title,
        slug: slug,
        content: content
      } 
    end
    yield(sections)
  end


  def api_navbar(document, current)
    if current.id == document.id
      sections = []
      (1..100).each do |i|
        title = document[document.type+'.sec' + i.to_s + '_title']
        next if title.nil?
        title = title.as_text
        slug = title.gsub(/[^a-zA-Z]/, '_').downcase
        sections << {
          title: title,
          slug: slug
        }
      end
      yield(sections)
    end
  end

end
