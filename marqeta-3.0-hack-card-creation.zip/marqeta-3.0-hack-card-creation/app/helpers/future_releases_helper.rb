module FutureReleasesHelper
  def render_release_dropdown
    render('layouts/header/releases_dropdown') unless Rails.env.production?
  end

  # TODO Implementation should be refactored
  def current_release
    return if PrismicStatus.api_down?
    @prismic = CmsService.prismic_api
    le_ref = @prismic.refs.find{ |key, ref| ref.id == session[:release_id] }
    le_ref.nil? ? :master : le_ref[1].label
  end

  def render_releases_list_items
    return if PrismicStatus.api_down?
    @prismic.refs.each do |key, ref|
      yield(key, ref.label)
    end
  end
end
