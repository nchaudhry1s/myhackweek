require 'mail'
class EmailValidator < ActiveModel::EachValidator
  BLACKLIST = [
    'pexcard.com'
  ]

  def validate_each(record,attribute,value)
    begin
      mail = Mail::Address.new(value)
      # We must check that value contains a domain and that it's not blacklisted
      response = mail.domain.present? && mail.address == value && !BLACKLIST.include?(mail.domain)
    rescue
      response = false
    end
    unless response
      Rails.logger.info "Refusing to create user with email address '#{value}' as we are blocking this domain."
      record.errors[:base] << "We’re sorry, we were unable to create a new account for you. Please try again later, or email us for more info. Thanks!"
    end
  end
end
