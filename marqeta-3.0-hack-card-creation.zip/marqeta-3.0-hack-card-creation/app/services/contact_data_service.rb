class ContactDataService
  include PrismicData
  attr_reader :id, :ref

  def initialize(ref)
    @ref = ref

    set_id
  end

  private

  def set_id
    @id = CmsService.config("id_mappings")["contact"]
  end

  def transformed_data
    {
      title_tag: value_for(:title_tag),
      meta_description: value_for(:meta_description),

      page_title: value_for(:page_title),

      primary_body: value_for(:primary_body),
      primary_image: value_for(:primary_image),

      section_one_title: value_for(:section_one_title),
      section_one_body: value_for(:section_one_body),
      section_one_link: value_for(:section_one_link),

      section_two_title: value_for(:section_two_title),
      section_two_body: value_for(:section_two_body),
      section_two_link_one: value_for(:section_two_link_one),
      section_two_link_two: value_for(:section_two_link_two),

      section_three_title: value_for(:section_three_title),
      section_three_body: value_for(:section_three_body),
      section_three_link_one: value_for(:section_three_link_one),
      section_three_link_two: value_for(:section_three_link_two),

      contact_form_header: value_for(:contact_form_header),
      contact_form_submission: value_for(:contact_form_submission),
      contact_form_thank_you: value_for(:contact_form_thank_you)
    }
  end
end
