require './lib/simple_collection'

class ZionBaseService

  def initialize(url, data = {})
    @url         = ZionBaseService.api_base_url + url
    @headers     = build_headers
    @data        = data.to_json
  end

  # Helper methods
  def self.api_base_url
    @api_base_url
  end

  def self.api_base_url=(url)
    @api_base_url = url
  end

  def self.password
    @password
  end

  def self.password=(password)
    @password = password
  end

  def self.username
    @username
  end

  def self.username=(username)
    @username = username
  end

  # Zion API calls
  def change
    response = RestClient.patch(@url, @data, @headers)
    safe_parse(response)
  end

  def create
    response = RestClient.post(@url, @data, @headers)
    safe_parse(response)
  end

  def delete
    # Need to pass params in headers when deleting access token
    @headers[:params] = JSON.parse(@data) if @data
    response = RestClient::Request.execute(method: :delete, url: @url, headers: @headers)
    safe_parse(response)
  end

  def find
    @url = add_query_params(@url, @data) unless JSON.parse(@data).empty?
    response = RestClient.get(@url, @headers)
    safe_parse(response)
  end

  def update
    response = RestClient.put(@url, @data, @headers)
    safe_parse(response)
  end

  private
  def add_query_params(url, data)
    url + "?" + JSON.parse(data).to_query
  end

  def auth_header_value
    Base64.strict_encode64([ZionBaseService.username, ZionBaseService.password].join(":"))
  end

  def build_headers
    _headers = {
      "Authorization" => "Basic #{auth_header_value}",
      "Content-Type" => "application/json"
    }
  end

  def safe_parse(response)
    JSON.parse(response)
    rescue JSON::ParserError
      response
  end

end
