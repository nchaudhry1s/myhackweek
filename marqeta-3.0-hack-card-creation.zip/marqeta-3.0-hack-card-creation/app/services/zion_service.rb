class ZionService < ZionBaseService
  # Assign each user an app token, with a program
  # Assign each user an access token, with a set of roles attached & an app token

  ZION_INFO = YAML.load_file(Rails.root.join('config/settings.yml'))["zion"]

  def self.create_application_token(token_value)
    data = {
        token: "#{token_value}",
        application_type: "marqeta",
        program: "shared-sandbox", # Hard coded for initial launch
        payments_api_base_url: ZION_INFO["payments_url"],
        active: true
    }
    new("/applications", data).create
  end

  def self.create_access_token(application_token, access_token, roles=[])
    # Roles confirmed by Dan
    roles = ["read", "write", "pci", "program-manager"] if roles.empty?
    data = {
        token: "#{access_token}",
        token_type: "master",
        application_token: "#{application_token}",
        master_roles: roles
    }
    new("/accesstokens", data).create
  end

  def self.delete_application_token(app_token)
    new("/applications/#{app_token}").delete
  end

  def self.delete_access_token(access_token, app_token)
    new("/accesstokens/#{access_token}", { application_token: app_token }).delete
  end

  def self.provision_zion_credentials(user_id)
    Rails.logger.info "Begin provisioning credentials for User with ID #{user_id}."
    Rails.logger.info "Setting Zion Base URL to #{ZION_INFO['url']}"
    Rails.logger.info "Setting username & password to values found in settings.yml"

    # Instantiate ZionBaseService
    ZionBaseService.api_base_url = ZION_INFO["url"]
    ZionBaseService.username = ZION_INFO["app_username"]
    ZionBaseService.password = ZION_INFO["app_password"]

    Rails.logger.info "Creating unique app_token and access_token for User."
    app_token = ["user", user_id, Time.now.to_i].join
    access_token = SecureRandom.uuid

    Rails.logger.info "Creating Credential object in marqeta.com database."
    cred = Credential.new
    cred.app_token = app_token
    cred.auth_token = access_token

    user = User.find(user_id)
    user.credential = cred

    Rails.logger.info "Creating application token in Zion."
    begin
      start = Time.now
      response = create_application_token(app_token)
      duration = ((Time.now - start) * 1000).round
      Rails.logger.info "Application token created successfully in #{duration}ms"
    rescue => error
      rollback(cred, user)
      log_and_raise(error, "create_application_token", duration)
    end

    Rails.logger.info "Creating access token in Zion."
    begin
      start = Time.now
      response = create_access_token(app_token, access_token)
      duration = ((Time.now - start) * 1000).round
      Rails.logger.info "Access token created successfully in #{duration}ms"
    rescue => error
      rollback(cred, user)
      log_and_raise(error, "create_access_token", duration)
    end

    Rails.logger.info "Finished provisioning credentials for User with ID #{user_id}"
  end

  def self.log_and_raise(error, method, duration)
    Rails.logger.error "Error in ZionService::#{method} finished in #{duration}ms with message #{error.message}"
    error.backtrace.each { |line| Rails.logger.error line }
    raise error
  end

  def self.rollback(credential, user)
    credential.destroy
    user.credential = nil
    user.save
  end

end
