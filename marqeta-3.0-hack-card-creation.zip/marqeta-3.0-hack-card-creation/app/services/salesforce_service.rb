class SalesforceService
  # Since we are applying each user to the same account, we no longer need any of the account creation code Seb wrote.
  # See his POC repo if it becomes necessary in the future.

  # Data updates

  def self.ensure_contact_exists(user_id, program_name)
    user = User.find(user_id)

    program = Program.where(name: program_name).first
    account_id = program.account_id
    user_program = user.program_record_for(program_name)
    if user_program.salesforce_contact_id.present?
      user_program.salesforce_contact_id
    else
      contact_id = create_contact(account_id, user.salesforce_create_params)
      user_program.salesforce_contact_id = contact_id
      user_program.save
      contact_id
    end
  end

  # Executed when a User updates their profile information
  def self.update_contact_info(user_id, program_name)
    user = User.find(user_id)
    contact_id = ensure_contact_exists(user.id, program_name)
    update_contact(contact_id, user.salesforce_update_params)
  end

  def self.create_contact(account_id=nil, attrs={})
    client.create!("Contact",
                    status__c: attrs[:state],
                    LeadSource: attrs.fetch(:lead_source, "New Registration"),
                    FirstName: attrs[:first_name],
                    LastName: attrs[:last_name],
                    Title: attrs[:title],
                    MobilePhone: attrs[:phone],
                    Email: attrs[:email],
                    Sandbox_Key__c: attrs[:shared_sandbox_key],
                    Preliminary_Company__c: attrs[:company],
                    Preliminary_Company_Size__c: attrs[:company_size], # <10, 10 - 50, 50 - 250, 250 - 1000, >1000
                    HasOptedOutOfEmail: attrs[:email_opt_in],
                    c_ID__c: attrs[:id],
                    AccountId: account_id
                  )
  end

  def self.update_contact(contact_id, attrs={})
    client.update!("Contact",
                    FirstName: attrs[:first_name],
                    LastName: attrs[:last_name],
                    Title: attrs[:title],
                    MobilePhone: attrs[:phone],
                    Email: attrs[:email],
                    Last_Login__c: attrs[:current_sign_in_at],
                    Login_Count__c: attrs[:sign_in_count],
                    Preliminary_Company__c: attrs[:company],
                    Preliminary_Company_Size__c: attrs[:company_size], # <10, 10 - 50, 50 - 250, 250 - 1000, >1000
                    HasOptedOutOfEmail: attrs[:email_opt_in],
                    Id: contact_id,
                  )
  end

  def self.config
    @config ||= YAML.load_file(Rails.root.join('config/settings.yml'))["salesforce"]
  end

  def self.client
    Restforce.new(
      username:       config["username"],
      password:       config["password"],
      security_token: config["security_token"],
      client_id:      config["client_id"],
      client_secret:  config["client_secret"],
      host:           config["host"],
      api_version:    "36.0"
    )
  end

end
