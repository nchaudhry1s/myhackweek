class FeatureDataService
  include PrismicData
  attr_reader :id, :ref

  SERVICE_FIELDS = ["service_title", "service_title_icon", "service_description", "service_button_text", "service_button_link", "service_image", "service_image_retina", "service_description_position"]

  def initialize(ref)
    @ref = ref

    set_id
  end

  private

  def set_id_for(key = nil)
    set_id
  end

  def set_id
    @id = CmsService.config("id_mappings")["features"]
  end

  def transformed_data
    {
      title_tag: value_for(:title_tag),
      meta_description: value_for(:meta_description),

      intro_title: value_for(:intro_title),
      intro_description: value_for(:intro_description),
      intro_button_text: value_for(:intro_button_text),
      intro_button_link: value_for(:intro_button_link),
      intro_image: value_for(:intro_image),
      intro_image_retina: value_for(:intro_image_retina),
      intro_small_image: value_for(:intro_small_image),
      intro_small_image_retina: value_for(:intro_small_image_retina),

      controls_title: value_for(:controls_title),
      controls: group_for("controls_services", SERVICE_FIELDS),

      insights_title: value_for(:insights_title),
      insights: group_for("insights_services", SERVICE_FIELDS),

      speed_to_market_title: value_for(:speed_to_market_title),
      speed_to_market: group_for("speed_to_market_services", SERVICE_FIELDS)
    }
  end
end
