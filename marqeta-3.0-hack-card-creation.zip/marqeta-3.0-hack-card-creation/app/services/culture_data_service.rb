class CultureDataService
  include PrismicData
  attr_reader :id, :ref

  def initialize(ref)
    @ref = ref

    set_id
  end

  private

  def set_id
    @id = CmsService.config("id_mappings")["culture"]
  end

  def transformed_data
    {
      title_tag: value_for(:title_tag),
      meta_description: value_for(:meta_description),

      how_we_can_help_header: value_for(:how_we_can_help_header),
      audacious_header: value_for(:audacious_header),
      sharing_header: value_for(:sharing_header),
      audacious_description: value_for(:audacious_description),
      when_you_work: value_for(:when_you_work),
      very_confident: value_for(:very_confident),

      core_value_one_header: value_for(:core_value_one_header),
      core_value_one_description: value_for(:core_value_one_description),

      core_value_two_header: value_for(:core_value_two_header),
      core_value_two_description: value_for(:core_value_two_description),

      core_value_three_header: value_for(:core_value_three_header),
      core_value_three_description: value_for(:core_value_three_description),

      core_value_four_header: value_for(:core_value_four_header),
      core_value_four_description: value_for(:core_value_four_description),

      core_value_five_header: value_for(:core_value_five_header),
      core_value_five_description: value_for(:core_value_five_description),

      employee_one_quote: value_for(:employee_one_quote),
      employee_one_name: value_for(:employee_one_name),
      employee_one_title: value_for(:employee_one_title),

      employee_two_quote: value_for(:employee_two_quote),
      employee_two_name: value_for(:employee_two_name),
      employee_two_title: value_for(:employee_two_title),

      employee_three_quote: value_for(:employee_three_quote),
      employee_three_name: value_for(:employee_three_name),
      employee_three_title: value_for(:employee_three_title),

      employee_four_quote: value_for(:employee_four_quote),
      employee_four_name: value_for(:employee_four_name),
      employee_four_title: value_for(:employee_four_title),

      employee_five_quote: value_for(:employee_five_quote),
      employee_five_name: value_for(:employee_five_name),
      employee_five_title: value_for(:employee_five_title),

      big_question_one_header: value_for(:big_question_one_header),
      big_question_one_main: value_for(:big_question_one_main),

      big_question_two_header: value_for(:big_question_two_header),
      big_question_two_main: value_for(:big_question_two_main)
    }
  end
end
