class BasicPageDataService
  include PrismicData
  attr_reader :id, :api, :ref

  def initialize(ref)
    @ref = ref
  end

  private

  def set_id_for(key = nil)
    @id = PAGE_ID_MAP[key]
  end

  PAGE_ID_MAP = {
    payments_basics: CmsService.config("id_mappings")["payments_basics"],
    api: CmsService.config("id_mappings")["api"],
    press: CmsService.config("id_mappings")["press"],
    api_explorer: CmsService.config("id_mappings")["api_explorer"]
  }.with_indifferent_access

  def transformed_data
    {
      title_tag: value_for(:title_tag),
      meta_description: value_for(:meta_description),
      main_heading: value_for(:main_heading),
      main_subheading: value_for(:main_subheading),
    }
  end
end
