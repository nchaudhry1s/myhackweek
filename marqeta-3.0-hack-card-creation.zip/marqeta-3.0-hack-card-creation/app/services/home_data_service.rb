class HomeDataService
  include PrismicData
  attr_reader :id, :api, :ref

  def initialize(ref)
    @ref = ref

    set_id
  end

  private

  def set_id_for(key = nil)
    set_id
  end

  def set_id
    @id = CmsService.config("id_mappings")["home"]
  end

  def transformed_data
    {
      title_tag: value_for(:title_tag),
      meta_description: value_for(:meta_description),
      main_heading: value_for(:main_heading),
      main_subheading: value_for(:main_subheading),

      bing_heading: value_for(:bing_heading),
      bing_main_text: value_for(:bing_main_text),
      bing_button_text: value_for(:bing_button_text),
      bing_button_link: value_for(:bing_button_link),

      bang_heading: value_for(:bang_heading),
      bang_main_text: value_for(:bang_main_text),
      bang_button_text: value_for(:bang_button_text),
      bang_button_link: value_for(:bang_button_link),
      bang_small_image: value_for(:bang_small_image),

      boom_heading: value_for(:boom_heading),
      boom_main_text: value_for(:boom_main_text),
      boom_button_text: value_for(:boom_button_text),
      boom_button_link: value_for(:boom_button_link),

      solution_cards: [
        {
          title: value_for(:solutions_card_1_title),
          content: value_for(:solutions_card_1_content),
          link_text: value_for(:solutions_card_1_link_text),
          link: value_for(:solutions_card_1_link)
        },
        {
          title: value_for(:solutions_card_2_title),
          content: value_for(:solutions_card_2_content),
          link_text: value_for(:solutions_card_2_link_text),
          link: value_for(:solutions_card_2_link)
        },
        {
          title: value_for(:solutions_card_3_title),
          content: value_for(:solutions_card_3_content),
          link_text: value_for(:solutions_card_3_link_text),
          link: value_for(:solutions_card_3_link)
        },
        {
          title: value_for(:solutions_card_4_title),
          content: value_for(:solutions_card_4_content),
          link_text: value_for(:solutions_card_4_link_text),
          link: value_for(:solutions_card_4_link)
        },
        {
          title: value_for(:solutions_card_5_title),
          content: value_for(:solutions_card_5_content),
          link_text: value_for(:solutions_card_5_link_text),
          link: value_for(:solutions_card_5_link)
        }
      ],
      features_heading: value_for(:features_heading),
      feature_cards: [
        {
          title: value_for(:feature_card_1_title),
          content: value_for(:feature_card_1_content),
          link_text: value_for(:feature_card_1_link_text),
          link: value_for(:feature_card_1_link),
          is_new: value_for(:feature_card_1_is_new) == "yes"
        },
        {
          title: value_for(:feature_card_2_title),
          content: value_for(:feature_card_2_content),
          link_text: value_for(:feature_card_2_link_text),
          link: value_for(:feature_card_2_link),
          is_new: value_for(:feature_card_2_is_new) == "yes"
        },
        {
          title: value_for(:feature_card_3_title),
          content: value_for(:feature_card_3_content),
          link_text: value_for(:feature_card_3_link_text),
          link: value_for(:feature_card_3_link),
          is_new: value_for(:feature_card_3_is_new) == "yes"
        }
      ],
      twitter_1_heading: value_for(:twitter_1_heading),
      twitter_2_heading: value_for(:twitter_2_heading)
    }
  end
end
