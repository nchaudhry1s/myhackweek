class CmsService
  extend PrismicApi

  attr_reader :ref, :id, :using_master_ref

  def initialize(ref: nil, id: nil, type: nil)
    @api = CmsService.prismic_api
    @id = id
    @type = type
    @ref = ref || master_ref
    @using_master_ref = ref_is_master(ref)
  end

  def ref_is_master(ref)
    if PrismicStatus.api_down? || uri?(ref)
      false
    else
      ref.is_master
    end
  end

  def self.init_by_title(title: nil, ref: nil)
    title.gsub!(/-/, "_")
    new(id: config("id_mappings")[title], ref: ref)
  end

  def get_documents
    begin
      @api.form("everything")
         .page_size(100)
         .query(query)
         .submit(@ref)
    rescue Exception => e
      Rails.logger.error "There was an error retrieving the documents from Prismic at #{Time.now} and the error was #{e} CMSSERVICE +++"
      return false
    end
  end

  def query
    if @id.nil?
      Prismic::Predicates::at('document.type', @type)
    else
      "[[:d = at(document.id, \"#{@id}\")]]"
    end
  end

  def retrieve
    return PrismicBackup.retrieve(id: @id, type: @type) if PrismicStatus.api_down?
    return (@id.nil? ? get_documents : get_documents.first) if uri?(ref) # Needed for preview
    cache_result = check_cached_value
    cms_result = cache_result[:expired] ? expired_flow : cache_result
    if !cache_result[:expired] || cms_result[:success]
      cms_result[:data]
    elsif !cms_result[:success] && cache_result[:data]
      cache_result[:data]
    else
      nil
    end
  end

  def check_cached_value
    Rails.logger.info "+++ CMSSERVICE obtaining the cached value at #{Time.now} CMSSERVICE +++"
    begin
      cached_result = Rails.cache.fetch(cache_key)
      if cached_result.nil?
        Rails.logger.info "+++ CMSSERVICE Cached Result Expired CMSSERVICE +++"
        return {expired: true}
      else
        return {expired: !(cached_result[:ref_id] == @ref.ref), data: cached_result[:data] }
      end
    rescue Exception => e
      Rails.logger.error "+++ CMSSERVICE There was an error obtaining the cached value at #{Time.now} and the error was #{e} CMSSERVICE +++"
      return false
    end
  end

  def expired_flow
    Rails.logger.info "+++ CMSSERVICE Getting Documents at #{Time.now} CMSSERVICE +++"
    begin
      result = get_documents
      if result
        Rails.logger.info "+++ CMSSERVICE Writing to the cache at #{Time.now} CMSSERVICE +++"
        Rails.cache.write(cache_key, {ref_id: @ref.ref, data: data_to_use(result)})
        {success: true, ref_id: @ref.ref, data: data_to_use(result)}
      else
        {success: false}
      end
    rescue Exception => e
      Rails.logger.error "+++ CMSSERVICE There was an error writing to the cache at #{Time.now} and the error was #{e} CMSSERVICE +++"
      return false
    end
  end

  def data_to_use(result)
    @id.nil? ? result : result.first
  end

  def cache_key
    if @using_master_ref
      "#{@id || @type}"
    else
      "#{@id || @type}_#{@ref.ref}"
    end
  end

  private

  def api_failure?
    !@api.instance_of? Prismic::API
  end

  def master_ref
    @api.master_ref unless api_failure?
  end

  def uri?(string)
    uri = URI.parse(string)
    %w( http https ).include?(uri.scheme)
    rescue URI::BadURIError
      false
    rescue URI::InvalidURIError
      false
  end

end

