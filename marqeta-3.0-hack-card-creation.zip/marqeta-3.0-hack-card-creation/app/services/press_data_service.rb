class PressDataService
  include PrismicData
  attr_reader :id, :ref

  def initialize(ref)
    @ref = ref

    set_id
  end

  private

  def set_id_for(key = nil)
    set_id
  end

  def set_id
    @id = CmsService.config("id_mappings")["press"]
  end

  def transformed_data
    {
      title_tag: value_for(:title_tag),
      meta_description: value_for(:meta_description),

      title: value_for(:page_title),
      introduction: value_for(:introduction),

      execs: group_for("exec_bio", ["exec_name", "exec_quote", "exec_position", "exec_description", "exec_image"]),

      press_contact_title: value_for(:press_contact_title),
      press_contact_description: value_for(:press_contact_description),
      press_email: value_for(:press_email),

      brand_assets_title: value_for(:brand_assets_title),
      brand_assets_description: value_for(:brand_assets_description)
    }
  end
end
