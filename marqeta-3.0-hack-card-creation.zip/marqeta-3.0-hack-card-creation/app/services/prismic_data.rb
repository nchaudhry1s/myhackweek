module PrismicData

  def self.get_value(document, key, ref)
    item = document.get("#{document.type}.#{key}")
    PrismicData.get_prismic_fragment_value(item, ref)
  end

  def self.get_prismic_fragment_value(fragment, ref = nil)
    if fragment.is_a?(Prismic::Fragments::StructuredText)
      fragment.as_html_safe
    elsif fragment.is_a?(Prismic::Fragments::Link)
      fragment.url(PrismicLinkResolver.link_resolver(ref))
    elsif fragment.is_a?(Prismic::Fragments::Image)
      fragment.main.url
    elsif fragment.nil?
      nil
    else
      fragment.value
    end
  end

  def self.get_group(document, group_name, keys)
    group = document.get_group("#{document.type}.#{group_name}")
    if group.blank?
      return []
    end
    group_items = []

    group.each do |group_item|
      item = {}
      keys.each do |key|
        item[key.to_sym] = PrismicData.get_prismic_fragment_value(group_item[key])
      end
      group_items.push(item)
    end
    group_items
  end

  def data
    return {} if id.nil?
    transformed_data if data_present?
  end

  def data_for(key)
    set_id_for(key)
    data
  end

  private

  def id
    raise "needs to be implemented by class"
  end

  def api
    raise "needs to be implemented by class"
  end

  def ref
    raise "needs to be implemented by class"
  end

  def set_id_for(key)
    raise "needs to be implemented by class"
  end

  def data_present?
    document.present?
  end

  def document
    @document ||= CmsService.new(id: @id, ref: @ref).retrieve
  end

  def timestamp
    Time.now.strftime("%Y-%m-%d-%H")
  end

  def value_for(key)
    return nil if id.nil?
    PrismicData.get_value(document, key, ref)
  end

  def group_for(group, keys)
    PrismicData.get_group(document, group, keys)
  end

  def transformed_data
    {}
  end
end
