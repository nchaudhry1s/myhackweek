class StaticDataService
  include PrismicData
  attr_reader :id, :api, :ref

  def initialize(ref)
    @ref = ref
  end

  private

  def set_id_for(key = nil)
    @id = PAGE_ID_MAP[key]
  end

  PAGE_ID_MAP = {
    about: CmsService.config("id_mappings")["about"],
    careers: CmsService.config("id_mappings")["careers"]
  }.with_indifferent_access

  def transformed_data
    {
      title_tag: value_for(:title_tag),
      meta_description: value_for(:meta_description),

      title: value_for(:title),
      content_title: value_for(:content_title),
      content: value_for(:content),
      image: value_for(:image),
      company_photo: value_for(:company_photo),
      top_photo: value_for(:top_photo),
      top_photo_small: value_for(:top_photo_small),
      bottom_photo: value_for(:bottom_photo)
    }
  end
end
