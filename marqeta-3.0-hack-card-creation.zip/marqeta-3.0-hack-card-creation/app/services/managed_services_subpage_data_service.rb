class ManagedServicesSubpageDataService
  include PrismicData
  attr_reader :id, :ref

  BANNER_FIELDS = [
    "alignment",
    "title",
    "description",
    "background_image",
    "cta_link_text",
    "cta_link"
  ]

  def initialize(ref)
    @ref = ref

    set_id
  end

  private

  def set_id
    @id = CmsService.config("id_mappings")["program_dashboard"]
  end

  def transformed_data
    {
      image_offset_hero_title: value_for(:image_offset_hero_title),
      image_offset_hero_description: value_for(:image_offset_hero_description),
      image_offset_hero_background_image_small: value_for(:image_offset_hero_background_image_small),
      image_offset_hero_background_image_large: value_for(:image_offset_hero_background_image_large),
      cta_link_text: value_for(:cta_link_text),
      cta_link_url: value_for(:cta_link_url),

      dividers_title: value_for(:dividers_title),
      paragraph_body: value_for(:paragraph_body),

      banners: group_for(:banners, BANNER_FIELDS),
    }
  end
end
