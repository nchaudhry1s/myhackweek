class ManagedServicesDataService
  include PrismicData
  attr_reader :id, :api, :ref

  def initialize(ref)
    @ref = ref
  end

  private

  def set_id_for(key = nil)
    @id = PAGE_ID_MAP[key]
  end

  PAGE_ID_MAP = {
    'ivr' => CmsService.config("id_mappings")["ivr"],
    'pci-widgets' => CmsService.config("id_mappings")["pci_widgets"]
  }.with_indifferent_access

  def transformed_data
    {
      title_tag: value_for(:title_tag),
      meta_description: value_for(:meta_description),
      main_heading: value_for(:main_heading),
      main_subheading: value_for(:main_subheading),

      icon: value_for(:icon),
      short_description: value_for(:short),
      content: value_for(:content),
      conclusion: value_for(:conclusion),
      image: value_for(:image),
      cta_text: value_for(:cta_text),
      cta_link: value_for(:cta_link),
      features: [
        {
          content: value_for(:features_1),
        },
        {
          content: value_for(:features_2)
        },
        {
          content: value_for(:features_3)
        }
      ]
    }
  end
end
