class CmsBackupService
  extend PrismicApi

  def self.backup
    api_object = CmsBackupService.prismic_api
    ref = api_object.master_ref.ref
    _documents = api_object.form("everything").page_size(100).submit(api_object.master_ref.ref).results
    _documents.each do |document|
      pb = ingest(ref, document)
      pb.save # we should make sure that everything is set up correctly before saving
    end
  end

  private

  def self.ingest(ref, document)
    prismic_id = document.id
    prismic_type = document.type
    prismic_object = Base64.encode64(Marshal.dump(document))
    json = document.as_json.to_s
    PrismicBackup.new(prismic_id: prismic_id, prismic_type: prismic_type, prismic_object: prismic_object, json: json, ref: ref)
  end

end
