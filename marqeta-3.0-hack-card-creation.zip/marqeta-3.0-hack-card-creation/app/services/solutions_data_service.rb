class SolutionsDataService
  include PrismicData
  attr_reader :id, :api, :ref

  BANNER_FIELDS = [
    "alignment",
    "title",
    "description",
    "background_image",
    "cta_link_text",
    "cta_link"
  ]

  def initialize(ref)
    @ref = ref
  end

  private

  def set_id_for(key = nil)
    @id = PAGE_ID_MAP[key]
  end

  PAGE_ID_MAP = {
    delivery: CmsService.config("id_mappings")["delivery"],
    lend: CmsService.config("id_mappings")["lend"],
    disburse: CmsService.config("id_mappings")["disburse"],
    expense: CmsService.config("id_mappings")["expense"],
    virtual: CmsService.config("id_mappings")["virtual"]
  }.with_indifferent_access

  def transformed_data
    {
      title_tag: value_for(:title_tag),
      meta_description: value_for(:meta_description),

      main_heading: value_for(:main_heading),
      main_subheading: value_for(:main_subheading),
      see_guide_link: value_for(:see_guide_link),
      benefits_heading: value_for(:benefits_heading),
      benefits_main: value_for(:benefits_main),

      hero_background_image: value_for(:hero_background_image),
      customer_logos_image: value_for(:customer_logos_image),

      banners: group_for(:banners, BANNER_FIELDS),

      case_study_main_image: value_for(:case_study_main_image),
      case_study_logo: value_for(:case_study_logo),
      case_study_logo_height: value_for(:case_study_logo_height),
      case_study_main: value_for(:case_study_main),
      case_study_read_more_link: value_for(:case_study_read_more_link),
      case_study_link: value_for(:case_study_link),
      case_study_link_text: value_for(:case_study_link_text),
      case_study_quote: value_for(:case_study_quote),
      case_study_name: value_for(:case_study_name),
      case_study_position: value_for(:case_study_position),
      case_study_quote_picture: value_for(:case_study_quote_picture),

      feature_cards: [
        {
          title: value_for(:feature_card_1_title),
          content: value_for(:feature_card_1_content),
          link_text: value_for(:feature_card_1_link_text),
          link: value_for(:feature_card_1_link),
          is_new: value_for(:feature_card_1_is_new) == "yes"
        },
        {
          title: value_for(:feature_card_2_title),
          content: value_for(:feature_card_2_content),
          link_text: value_for(:feature_card_2_link_text),
          link: value_for(:feature_card_2_link),
          is_new: value_for(:feature_card_2_is_new) == "yes"
        },
        {
          title: value_for(:feature_card_3_title),
          content: value_for(:feature_card_3_content),
          link_text: value_for(:feature_card_3_link_text),
          link: value_for(:feature_card_3_link),
          is_new: value_for(:feature_card_3_is_new) == "yes"
        }
      ]
    }
  end
end
