class PrismicLinkResolver
  def self.link_resolver(link_fragment)
    Prismic.link_resolver(link_fragment) do |doc_link|
      build_link(doc_link)
    end
  end

  def self.build_link(document)
    if document.type == "home"
      paths.root_path
    elsif document.type == "ref"
      paths.references_doc_path(id: document.id, slug: document.slug)
    elsif document.type == "guide"
      paths.api_guide_path(id: document.id, slug: document.slug)
    elsif document.type == "solution"
      paths.solutions_page_path(id: document.slug)
    elsif document.type == "mserv"
      paths.managed_services_page_path(id: document.slug)
    else
      "/#{document.slug}"
    end
  end

  def self.paths
    Rails.application.routes.url_helpers
  end
end
