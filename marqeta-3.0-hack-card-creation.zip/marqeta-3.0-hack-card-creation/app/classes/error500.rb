class Error500 < StandardError
end
