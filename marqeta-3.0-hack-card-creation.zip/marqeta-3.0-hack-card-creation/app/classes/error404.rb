class Error404 < StandardError
end
