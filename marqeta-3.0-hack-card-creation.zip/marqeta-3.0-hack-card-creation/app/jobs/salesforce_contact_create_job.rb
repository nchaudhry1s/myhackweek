class SalesforceContactCreateJob < BaseJob
  extend Resque::Plugins::Retry
  @queue = :salesforce_sync
  @retry_limit = 3
  @retry_delay = 60 # seconds

  def self.perform(user_id, program_name)
    Resque.logger.info "Creating User with ID #{user_id} in Salesforce."
    begin
      SalesforceService.ensure_contact_exists(user_id, program_name)
    rescue => error
      log_and_raise(error, "ensure_contact_exists", "SalesforceService")
    end
  end

end
