class SalesforceContactUpdateJob < BaseJob
  extend Resque::Plugins::Retry
  @queue = :salesforce_sync
  @retry_limit = 3
  @retry_delay = 60 # seconds

  def self.perform(user_id, program_name)
    Resque.logger.info "Updating User with ID #{user_id} in Salesforce."
    begin
      SalesforceService.update_contact_info(user_id, program_name)
    rescue => error
      log_and_raise(error, "update_contact_info", "SalesforceService")
    end
  end
end

