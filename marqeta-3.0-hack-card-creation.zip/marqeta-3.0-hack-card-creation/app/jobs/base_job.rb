class BaseJob

  def self.log_and_raise(error, method, service)
    Resque.logger.level = Logger::DEBUG
    Resque.logger.error "Error in #{service}::#{method}... #{error.message}"
    error.backtrace.each { |line| Resque.logger.error line }
    raise error
  end

end
