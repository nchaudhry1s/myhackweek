class ZionDeleteJob < BaseJob
  extend Resque::Plugins::Retry
  @queue = :zion_queue
  @retry_limit = 3
  @retry_delay = 60 # seconds

  ZION_INFO = YAML.load_file(Rails.root.join('config/settings.yml'))["zion"]

  def self.perform(user_id)
    Resque.logger.info "Begin DELETING Zion credentials for User with ID: #{user_id}"

    Resque.logger.info "Finding User with ID: #{user_id}"
    user = User.find(user_id)

    Resque.logger.info "Finding app & access token for User with ID: #{user.id}"
    app_token = user.safe_app_token
    access_token = user.safe_auth_token

    Resque.logger.info "Setting Zion Base URL to #{ZION_INFO['url']}"
    Resque.logger.info "Setting username & password to values found in settings.yml"
    ZionBaseService.api_base_url = ZION_INFO["url"]
    ZionBaseService.username = ZION_INFO["app_username"]
    ZionBaseService.password = ZION_INFO["app_password"]

    Resque.logger.info "Begin DELETING access token."
    begin
      ZionService.delete_access_token(access_token, app_token)
    rescue RestClient::BadRequest, RestClient::ResourceNotFound, RestClient::Unauthorized => error
      log_and_raise(error, "delete_access_token", "ZionService")
    end

    Resque.logger.info "Begin DELETING app token."
    begin
      ZionService.delete_application_token(app_token)
    rescue RestClient::BadRequest, RestClient::ResourceNotFound, RestClient::Unauthorized => error
      log_and_raise(error, "delete_app_token", "ZionService")
    end
  end
end
