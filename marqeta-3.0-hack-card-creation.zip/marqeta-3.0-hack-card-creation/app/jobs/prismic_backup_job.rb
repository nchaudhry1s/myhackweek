class PrismicBackupJob < BaseJob
  extend Resque::Plugins::Retry
  @queue = :prismic_backup

  def self.perform
    # Backs up our prismic data
    CmsBackupService.backup
    # Removes old prismic data (older than 7 days)
    PrismicBackup.prune_db
  end
end
