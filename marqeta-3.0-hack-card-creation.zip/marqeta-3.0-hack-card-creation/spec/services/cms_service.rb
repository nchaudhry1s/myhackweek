require 'rails_helper'

describe CmsService do
  context 'initialization' do
    it 'should initialize a CmsService object' do
      result = CmsService.new
      expect(result.is_a?(CmsService)).to eq(true)
    end
    it 'should use ref provided if one is provided as an argument' do
      result = CmsService.new(ref: "123")
      expect(result.ref).to eq("123")
    end
    it 'should retrieve and use the master ref if no ref is provided as an argument' do
      expect_any_instance_of(CmsService).to receive(:master_ref).and_return("123")
      result = CmsService.new
      expect(result.ref).to eq("123")
    end
    it 'should set using_master_ref instance variable to true if no ref is provided' do
      expect_any_instance_of(CmsService).to receive(:master_ref).and_return("123")
      result = CmsService.new
      expect(result.using_master_ref).to eq(true)
    end
  end

  context '#check_cached_value' do
    it "should return whether or not the cached value is expired" do
      result = CmsService.new(id: "123").check_cached_value
      expect(result[:expired]).to eq(true)
    end
  end

  context '#expired_flow' do
    it "should return a hash with a key :success and a key :data if successful" do
      expect_any_instance_of(CmsService).to receive(:get_documents).and_return({foo: "bar"})
      result = CmsService.new(id: "123").expired_flow
      expect(result[:data]).to eq({foo: "bar"})
    end
    it "should return a hash with a single key :success if there is a failure" do
      expect_any_instance_of(CmsService).to receive(:get_documents).and_return(nil)
      result = CmsService.new(id: "123").expired_flow
      expect(result[:success]).to eq(false)
    end
  end

  context '#retrieve' do
    it "should return the prismic document requested if successful" do
      expect_any_instance_of(CmsService).to receive(:get_documents).and_return({foo: "bar"})
      result = CmsService.new(id: "123").expired_flow
      expect(result[:data]).to eq({foo: "bar"})
    end
    it "should return nil if there is no cached document and the call to prismic fails" do
      expect_any_instance_of(CmsService).to receive(:get_documents).and_return(nil)
      result = CmsService.new(id: "123").expired_flow
      expect(result[:success]).to eq(false)
    end
  end
end
