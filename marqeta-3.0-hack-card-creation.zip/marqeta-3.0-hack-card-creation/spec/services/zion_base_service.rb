require 'rails_helper'

describe ZionBaseService do
  context 'initialization' do
    it 'should instantiate a ZionBaseService object' do
      ZionBaseService.api_base_url = "https://some_base_url"
      zion_obj = ZionBaseService.new("/foo", { foo: "bar" })
      expect(zion_obj.nil?).to eq(false)
    end

    context 'getter and setter methods' do
      before do
        ZionBaseService.api_base_url = "foo url"
        ZionBaseService.password = "foo password"
        ZionBaseService.username = "foo username"
      end

      it '#self.api_base_url= should set the api_base_url' do
        ZionBaseService.api_base_url = "new foo url"
        expect(ZionBaseService.api_base_url).to eq("new foo url")
      end

      it '#self.api_base_url should return the api_base_url' do
        expect(ZionBaseService.api_base_url).to eq("foo url")
      end

      it '#self.password= should set the password' do
        ZionBaseService.password = "new foo password"
        expect(ZionBaseService.password).to eq("new foo password")
      end

      it '#self.password should return the password' do
        expect(ZionBaseService.password).to eq("foo password")
      end

      it '#self.username= should set the username' do
        ZionBaseService.username = "new foo username"
        expect(ZionBaseService.username).to eq("new foo username")
      end

      it '#self.username should return the username' do
        expect(ZionBaseService.username).to eq("foo username")
      end
    end

    context 'headers' do
      before do
        ZionBaseService.api_base_url = "https://some_base_url"
        ZionBaseService.username = "foo"
        ZionBaseService.password = "bar"
      end

      it 'should include content type JSON' do
        zion_obj = ZionBaseService.new("/foo", { foo: "bar" })
        expect(zion_obj.instance_variable_get("@headers")["Content-Type"]).to eq("application/json")
      end

      it 'should include a base64 encoded Authorization value' do
        zion_obj = ZionBaseService.new("/foo", { foo: "bar" })
        authorization_value = "Basic " + Base64.strict_encode64([ZionBaseService.username, ZionBaseService.password].join(":"))
        expect(zion_obj.instance_variable_get("@headers")["Authorization"]).to eq(authorization_value)
      end
    end
  end
end

