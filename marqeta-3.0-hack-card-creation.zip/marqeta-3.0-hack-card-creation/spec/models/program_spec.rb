require 'rails_helper'

describe Program do
  context 'associations' do
    it 'should have many Users' do
      program = Program.reflect_on_association(:users)
      expect(program.macro).to eq(:has_many)
    end

    it 'should have many Credentials' do
      program = Program.reflect_on_association(:credentials)
      expect(program.macro).to eq(:has_many)
    end
  end

  context 'creation' do
    it 'should exist' do
      program = Program.new
      expect(program.nil?).to eq(false)
    end

    it 'should save' do
      program = Program.new(name: "Foo")
      expect(program.save).to eq(true)
    end
  end

  context 'helpers' do
    it '#self.shared_sandbox should find the Shared Sandbox program (which should have ID 1)' do
      program = Program.create(name: "Shared Sandbox", id: 1)
      expect(Program.shared_sandbox).to eq(program)
    end
  end
end
