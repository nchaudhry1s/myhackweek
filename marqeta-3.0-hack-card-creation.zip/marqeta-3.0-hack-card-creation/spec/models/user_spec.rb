require 'rails_helper'

describe User do
  context 'associations' do
    it 'should have many Programs' do
      user = User.reflect_on_association(:programs)
      expect(user.macro).to eq(:has_many)
    end

    it 'should have one Credential' do
      user = User.reflect_on_association(:credential)
      expect(user.macro).to eq(:has_one)
    end
  end

  context 'creation' do
    it 'should exist' do
      user = User.new
      expect(user.nil?).to eq(false)
    end

    it 'should require email presence' do
      user = User.new(email: nil, password: "Password123$")
      expect(user.valid?).to eq(false)
    end

    it 'should require an 8 character or greater password with 1 uppercase, 1 lowercase, 1 number & 1 special character' do
      # No special
      user = User.new(email: "foo@bar.com", password: "Password123")
      expect(user.valid?).to eq(false)

      # No digit
      user = User.new(email: "foo@bar.com", password: "Password!@#")
      expect(user.valid?).to eq(false)

      # No uppercase
      user = User.new(email: "foo@bar.com", password: "password123$}")
      expect(user.valid?).to eq(false)

      # No lowercase
      user = User.new(email: "foo@bar.com", password: "PASSWORD123$")
      expect(user.valid?).to eq(false)

      # Not 8 characters
      user = User.new(email: "foo@bar.com", password: "Pas123$")
      expect(user.valid?).to eq(false)
    end

    it 'should save if email and password are valid' do
      user = User.new(email: "foo@bar.com", password: "Password123$")
      # We don't want confirmation email to be sent
      user.skip_confirmation!
      expect(user.save).to eq(true)
    end
  end

  context 'helpers' do
    before do
      @user = User.new(email: "foo@bar.com", password: "Password123$")
      @user.skip_confirmation!
      @user.save
    end

    it '#confirmed? should return false if the user has not been confirmed' do
      user = User.new(email: "foo@bar.com", password: "Password123$")
      expect(user.confirmed?).to eq(false)
    end

    it '#current_roles should return an array of role names for a given user' do
      program = Program.new(name: "Foo")
      @user.add_role(:program_admin, program)
      expect(@user.current_roles(program)).to eq(["program_admin"])
    end

    it '#first_login? should return false if the user has not logged in yet or has logged in more than once' do
      expect(@user.first_login?).to eq(false)

      @user.sign_in_count = 2
      expect(@user.first_login?).to eq(false)
    end

    it '#first_login? should return true if the user has logged in once' do
      @user.sign_in_count = 1
      expect(@user.first_login?).to eq(true)
    end

    it '#program_record_for should return the user_program_record for a user and program' do
      program = Program.new(name: "Foo")
      program.save
      user_program_record = UserProgramRecord.new(user_id: @user.id, program_id: program.id)
      user_program_record.save
      expect(@user.program_record_for(program.name)).to eq(user_program_record)
    end

    it '#safe_app_token should return a user\'s app token if it is present' do
      credential = Credential.new(user_id: @user.id, app_token: "foo", auth_token: "bar")
      credential.save
      expect(@user.safe_app_token).to eq(credential.app_token)
    end

    it '#safe_app_token should return nil if a user has no app token' do
      expect(@user.safe_app_token).to eq(nil)
    end

    it '#safe_auth_token should return a user\'s auth token if it is present' do
      credential = Credential.new(user_id: @user.id, app_token: "foo", auth_token: "bar")
      credential.save
      expect(@user.safe_auth_token).to eq(credential.auth_token)
    end

    it '#safe_auth_token should return nil if a user has no auth token' do
      expect(@user.safe_auth_token).to eq(nil)
    end
  end

  context 'salesforce helpers' do
    before do
      @user = User.new(email: "foo@bar.com", password: "Password123$")
      @user.skip_confirmation!
      @user.save
    end

    it '#salesforce_create_params displays a hash of values that are acceptable for creating a user in Salesforce' do
      acceptable_create_keys = [:state, :first_name, :last_name, :title, :phone, :email, :shared_sandbox_key, :company, :company_size, :email_opt_in, :id]
      expect(@user.salesforce_create_params.keys).to eq(acceptable_create_keys)
    end

    it '#salesforce_update_params displays a hash of values that are acceptable for updating a user in Salesforce' do
      acceptable_update_keys = [:first_name, :last_name, :title, :phone, :email, :shared_sandbox_key, :current_sign_in_at, :sign_in_count, :company, :company_size, :email_opt_in, :id]
      expect(@user.salesforce_update_params.keys).to eq(acceptable_update_keys)
    end
  end

  context 'state machine' do
    it 'should set the user\'s state to active when instantiated' do
      user = User.new(email: "foo@bar.com", password: "Password123$")
      expect(user.active?).to eq(true)
    end

    it 'should set the user\'s state to terminated after calling the terminate event' do
      user = User.new(email: "foo@bar.com", password: "Password123$")
      user.skip_confirmation!
      user.terminate
      expect(user.terminated?).to eq(true)
    end
  end
end
