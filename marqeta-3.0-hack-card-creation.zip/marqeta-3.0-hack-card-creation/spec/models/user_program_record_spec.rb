require 'rails_helper'

describe UserProgramRecord do
  context 'associations' do
    it 'should belong to a Program' do
      user_program_record = UserProgramRecord.reflect_on_association(:program)
      expect(user_program_record.macro).to eq(:belongs_to)
    end

    it 'should belong to a User' do
      user_program_record = UserProgramRecord.reflect_on_association(:user)
      expect(user_program_record.macro).to eq(:belongs_to)
    end
  end

  context 'creation' do
    it 'should exist' do
      user_program_record = UserProgramRecord.new
      expect(user_program_record.nil?).to eq(false)
    end

    it 'should save' do
      user = User.new(email: "foo@bar.com", password: "Password123$")
      user.skip_confirmation!
      user.save
      program = Program.create(name: "Foo")
      user_program_record = UserProgramRecord.new(user_id: user.id, program_id: program.id, salesforce_contact_id: "123456789")
      expect(user_program_record.save).to eq(true)
    end
  end
end
