require 'rails_helper'

describe Credential do
  context 'associations' do
    it 'should belong to a Program' do
      credential = Credential.reflect_on_association(:program)
      expect(credential.macro).to eq(:belongs_to)
    end

    it 'should belong to a User' do
      credential = Credential.reflect_on_association(:user)
      expect(credential.macro).to eq(:belongs_to)
    end
  end

  context 'creation' do
    it 'should exist' do
      credential = Credential.new
      expect(credential.nil?).to eq(false)
    end

    it 'should save' do
      user = User.new(email: "foo@bar.com", password: "Password123$")
      user.skip_confirmation!
      user.save
      program = Program.create(name: "Foo")
      credential = Credential.new(user_id: user.id, program_id: program.id)
      expect(credential.save).to eq(true)
    end
  end
end
