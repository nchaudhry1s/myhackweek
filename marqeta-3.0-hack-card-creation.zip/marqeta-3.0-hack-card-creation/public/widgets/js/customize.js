$( document ).ready(function() {
  var textColor = '#999';
  function setHover( property, hoverColor, origColor ) {
    $('.iframe-border .button').hover(
      function() {
        $(this).css(property, hoverColor);
      }, function() {
        $(this).css(property, origColor);
      })
  }

  $('.color_input, .background_input').spectrum({
      preferredFormat: "hex6",
      change: function(color) {
          var selectedcolor = color.toHex();
          $(this).parent().find('.hex_color').val('#' + selectedcolor);
      }
  })

  $('.customize .button').click(function() {
    var thisClass = $(this).attr('class').replace('button ', '');
    var thisVal = $(this).prev().val();
    if( thisClass == 'background-hover' || thisClass == 'font-hover' || thisClass == 'placeholder-color') {
      if( thisClass == 'background-hover' ) {
        var hoverColor = $(this).prev().val();
        var origColor = $('.iframe-border .button').css('background');
        setHover( 'background', hoverColor, origColor );
      } else if( thisClass == 'font-hover') {
        var origColor = $('.iframe-border .button').css('color');
        var hoverColor = $(this).prev().val();
        setHover( 'color', hoverColor, origColor );
      } else if( thisClass == 'placeholder-color') {
        $('.iframe-border label').css('color', thisVal);
        textColor = thisVal;
      }
    } else {
      var mainID = $(this).parent().parent().attr('id');
      if( thisVal != '' ) {
        if( mainID == 'global' ) {
          $('.iframe-border').css(thisClass, thisVal);
        } else if (mainID == 'headers') {
          $('.iframe-border h2').css(thisClass, thisVal);
        } else if (mainID == 'errors' ) {
          $('.iframe-border ul').css(thisClass, thisVal).show().delay(5000).fadeOut();
        } else {
          $('.iframe-border .button').css( thisClass, thisVal );
        }
      } else {
        alert("No value to change to.");
      }
    }
  });

  $('.checkbox').click(function() {
    var checkboxName = $(this).attr("name");
    $('.' + checkboxName).toggle($(this)[0].checked);
  })

  //outputs the styles into the textarea
  $('.showStyles').click(function() {
    var styles = '';
    var thisID = '';
    $( ".customize .row" ).each( function( index, element ) {
      var showID = '';
      if( thisID != $(this).parent().attr('id')) {
        thisID = $(this).parent().attr('id');
        showID = thisID.toUpperCase() + '\n';
      }
      if ($( this ).find('.checkbox-label').length > 0 ) {
        styles += showID + $(this).find('.checkbox-label').html() + ": " + $(this).find('.checkbox')[0].checked + '\n';
      } else {
        styles += showID + $( this ).find('.button').html() + ": " +  $(this).find('.button').prev().val() + '\n';
      }
    });
    if( $('.iframe-width').val() != '' ) {
      styles += 'iFrame Width: ' + $('.iframe-width').val();
    }
    if( $('.iframe-height').val() != '' ) {
      styles += 'iFrame Height: ' + $('.iframe-height').val();
    }
    $('.show-styles').html(styles).show();
    $('.copyStyles').css('display','inline-block');
  });

  //allows the user to select the styles
  $('.copyStyles').click(function() {
    $('.show-styles').select();
    var text = $('.show-styles').val();
    alert("Please click 'ctrl+c' on a pc or 'cmd+c' on mac to copy selected text")
  });

  //change dimensions of the iframe
  $('.change-dimensions').click(function() {
    if( $('.iframe-width').val() == '' || $('.iframe-height').val() == '') {
      alert("Please enter the dimensions you want.")
    } else {
      $('.iframe-border').css('width', $('.iframe-width').val());
      $('.iframe-border').css('height', $('.iframe-height').val());
    }
  });

  $(".iframe-border input[type='text']").focus(function() {
      $(this).css('color', "#999");
  });
  $(".iframe-border input[type='text']").focusout(function() {
      $(this).css('color', textColor);
  });
});
