# Changes made to bower sources

## Affects /api_explorer page

```
@@ -22416,7 +22416,7 @@ SwaggerUi.Views.MainView = Backbone.View.extend({

   addResource: function(resource, auths){
     // Render a resource and add it to resources li
-    resource.id = resource.id.replace(/\s/g, '_');
+    resource.id = resource.id.replace(/[[\]{}()*+?,\\/^$|#\s]/g, '_');

     // Make all definitions available at the root of the resource so that they can
     // be loaded by the JSonEditor
```

## Fixes the generation of curls in swagger

```
@@ -7494,7 +7494,7 @@ Operation.prototype.asCurl = function (args1, args2) {
       body = obj.body;
     }
     // escape @ => %40, ' => %27
-    body = body.replace(/\'/g, '%27').replace(/\n/g, ' \\ \n ');
+    body = body.replace(/\'/g, '%27').replace(/\n/g, ' \n ');

     if(!isFormData) {
       // escape & => %26
```
